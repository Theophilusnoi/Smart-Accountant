import { RouterProvider } from 'react-router-dom'
import { AuthProvider } from './hooks/useAuth.jsx'
import { IndustryProvider } from './contexts/IndustryContext'
import { router } from './routes'
import './App.css'

function App() {
  return (
    <AuthProvider>
      <IndustryProvider>
        <RouterProvider router={router} />
      </IndustryProvider>
    </AuthProvider>
  )
}

export default App

