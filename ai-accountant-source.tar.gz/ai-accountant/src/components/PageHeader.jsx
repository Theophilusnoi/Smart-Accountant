import BackButton from './BackButton'

const PageHeader = ({ 
  title, 
  subtitle = null, 
  showBackButton = true, 
  backTo = null,
  children = null 
}) => {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          {showBackButton && (
            <BackButton 
              to={backTo}
              variant="outline"
              size="sm"
            />
          )}
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
            {subtitle && (
              <p className="text-gray-600 mt-1">{subtitle}</p>
            )}
          </div>
        </div>
        
        {children && (
          <div className="flex items-center space-x-3">
            {children}
          </div>
        )}
      </div>
    </div>
  )
}

export default PageHeader

