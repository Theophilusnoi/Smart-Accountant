import { Outlet, useLocation } from 'react-router-dom'
import Header from './Header'
import Footer from './Footer'

const Layout = () => {
  const location = useLocation()
  const isHomePage = location.pathname === '/'

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <Header />
      <main className={isHomePage ? '' : 'pt-16'}>
        <Outlet />
      </main>
      {isHomePage && <Footer />}
    </div>
  )
}

export default Layout

