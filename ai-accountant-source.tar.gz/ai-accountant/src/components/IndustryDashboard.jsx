import React from 'react';
import { useIndustry } from '../contexts/IndustryContext';
import { 
  Hotel, Hammer, ShoppingCart, Heart, Factory, Briefcase, Home, Users,
  TrendingUp, DollarSign, BarChart3, PieChart, Calendar, AlertCircle
} from 'lucide-react';

// Industry-specific dashboard widgets
const IndustryWidgets = {
  hospitality: {
    'occupancy-rate': {
      title: 'Occupancy Rate',
      value: '87.5%',
      change: '+5.2%',
      trend: 'up',
      icon: Hotel,
      color: 'blue'
    },
    'adr-revenue': {
      title: 'Average Daily Rate',
      value: '$245',
      change: '+12.3%',
      trend: 'up',
      icon: DollarSign,
      color: 'green'
    },
    'revpar-analysis': {
      title: 'RevPAR',
      value: '$214',
      change: '+18.7%',
      trend: 'up',
      icon: TrendingUp,
      color: 'purple'
    },
    'fb-revenue': {
      title: 'F&B Revenue',
      value: '$45,230',
      change: '+8.4%',
      trend: 'up',
      icon: BarChart3,
      color: 'orange'
    },
    'guest-satisfaction': {
      title: 'Guest Satisfaction',
      value: '4.8/5',
      change: '+0.2',
      trend: 'up',
      icon: Heart,
      color: 'pink'
    },
    'seasonal-trends': {
      title: 'Seasonal Booking',
      value: '92%',
      change: '+15%',
      trend: 'up',
      icon: Calendar,
      color: 'indigo'
    }
  },
  construction: {
    'job-profitability': {
      title: 'Job Profitability',
      value: '18.5%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'green'
    },
    'project-progress': {
      title: 'Projects On Track',
      value: '12/15',
      change: '80%',
      trend: 'stable',
      icon: Hammer,
      color: 'blue'
    },
    'equipment-utilization': {
      title: 'Equipment Utilization',
      value: '76%',
      change: '+4%',
      trend: 'up',
      icon: Factory,
      color: 'orange'
    },
    'subcontractor-costs': {
      title: 'Subcontractor Costs',
      value: '$125,400',
      change: '-3.2%',
      trend: 'down',
      icon: Users,
      color: 'purple'
    },
    'material-costs': {
      title: 'Material Costs',
      value: '$89,650',
      change: '+1.8%',
      trend: 'up',
      icon: BarChart3,
      color: 'red'
    },
    'safety-metrics': {
      title: 'Safety Score',
      value: '98.5%',
      change: '+0.5%',
      trend: 'up',
      icon: AlertCircle,
      color: 'green'
    }
  },
  retail: {
    'sales-performance': {
      title: 'Total Sales',
      value: '$234,567',
      change: '+15.3%',
      trend: 'up',
      icon: ShoppingCart,
      color: 'green'
    },
    'inventory-turnover': {
      title: 'Inventory Turnover',
      value: '6.2x',
      change: '+0.8x',
      trend: 'up',
      icon: BarChart3,
      color: 'blue'
    },
    'customer-metrics': {
      title: 'Customer Acquisition',
      value: '1,245',
      change: '+23%',
      trend: 'up',
      icon: Users,
      color: 'purple'
    },
    'channel-performance': {
      title: 'Online vs Store',
      value: '65/35',
      change: '+5%',
      trend: 'up',
      icon: PieChart,
      color: 'orange'
    },
    'margin-analysis': {
      title: 'Gross Margin',
      value: '42.3%',
      change: '+1.2%',
      trend: 'up',
      icon: TrendingUp,
      color: 'green'
    },
    'seasonal-trends': {
      title: 'Seasonal Index',
      value: '1.15',
      change: '+0.05',
      trend: 'up',
      icon: Calendar,
      color: 'indigo'
    }
  },
  healthcare: {
    'patient-volume': {
      title: 'Patient Volume',
      value: '1,456',
      change: '+8.2%',
      trend: 'up',
      icon: Heart,
      color: 'red'
    },
    'insurance-collections': {
      title: 'Insurance Collections',
      value: '$145,230',
      change: '+12.5%',
      trend: 'up',
      icon: DollarSign,
      color: 'green'
    },
    'provider-performance': {
      title: 'Provider Efficiency',
      value: '94.2%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'blue'
    },
    'compliance-status': {
      title: 'Compliance Score',
      value: '99.1%',
      change: '+0.3%',
      trend: 'up',
      icon: AlertCircle,
      color: 'green'
    },
    'equipment-utilization': {
      title: 'Equipment Usage',
      value: '82%',
      change: '+5%',
      trend: 'up',
      icon: Factory,
      color: 'purple'
    },
    'patient-satisfaction': {
      title: 'Patient Satisfaction',
      value: '4.7/5',
      change: '+0.1',
      trend: 'up',
      icon: Heart,
      color: 'pink'
    }
  }
};

const WidgetCard = ({ widget, widgetKey }) => {
  const IconComponent = widget.icon;
  const isPositive = widget.trend === 'up';
  const isNegative = widget.trend === 'down';

  const colorClasses = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    purple: 'bg-purple-500',
    orange: 'bg-orange-500',
    red: 'bg-red-500',
    pink: 'bg-pink-500',
    indigo: 'bg-indigo-500'
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-10 h-10 ${colorClasses[widget.color]} rounded-lg flex items-center justify-center`}>
          <IconComponent className="w-5 h-5 text-white" />
        </div>
        <div className={`flex items-center text-sm font-medium ${
          isPositive ? 'text-green-600' : isNegative ? 'text-red-600' : 'text-gray-600'
        }`}>
          {widget.change}
          {isPositive && <TrendingUp className="w-4 h-4 ml-1" />}
          {isNegative && <TrendingUp className="w-4 h-4 ml-1 rotate-180" />}
        </div>
      </div>
      
      <div>
        <h3 className="text-2xl font-bold text-gray-900 mb-1">{widget.value}</h3>
        <p className="text-sm text-gray-600">{widget.title}</p>
      </div>
    </div>
  );
};

const IndustryDashboard = () => {
  const { selectedIndustry, getDashboardWidgets } = useIndustry();

  if (!selectedIndustry) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <BarChart3 className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          Select Your Industry
        </h3>
        <p className="text-gray-600 mb-4">
          Choose your industry to see specialized dashboard widgets and metrics.
        </p>
        <button className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
          Select Industry
        </button>
      </div>
    );
  }

  const widgetKeys = getDashboardWidgets();
  const industryWidgets = IndustryWidgets[selectedIndustry] || {};

  return (
    <div className="space-y-6">
      {/* Industry Header */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {selectedIndustry.charAt(0).toUpperCase() + selectedIndustry.slice(1)} Dashboard
        </h2>
        <p className="text-gray-600">
          Industry-specific metrics and insights for your business
        </p>
      </div>

      {/* Dashboard Widgets Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {widgetKeys.map((widgetKey) => {
          const widget = industryWidgets[widgetKey];
          if (!widget) return null;

          return (
            <WidgetCard 
              key={widgetKey} 
              widget={widget} 
              widgetKey={widgetKey}
            />
          );
        })}
      </div>

      {/* Industry Insights */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Industry Insights
        </h3>
        <div className="space-y-3">
          {selectedIndustry === 'hospitality' && (
            <>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Your occupancy rate is 12% above industry average for this season.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  F&B revenue per guest has increased by 8.4% compared to last month.
                </p>
              </div>
            </>
          )}
          {selectedIndustry === 'construction' && (
            <>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Project profitability is trending upward with improved cost control.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Equipment utilization can be optimized by 15% with better scheduling.
                </p>
              </div>
            </>
          )}
          {selectedIndustry === 'retail' && (
            <>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Online sales growth is outpacing industry benchmarks by 23%.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Inventory turnover has improved, reducing carrying costs by $12,000.
                </p>
              </div>
            </>
          )}
          {selectedIndustry === 'healthcare' && (
            <>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Patient volume growth indicates strong practice performance.
                </p>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <p className="text-gray-600">
                  Insurance collection rates are above industry average at 94.2%.
                </p>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default IndustryDashboard;

