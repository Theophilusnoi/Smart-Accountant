import { useNavigate } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'

const BackButton = ({ 
  to = null, 
  label = "Back", 
  className = "", 
  variant = "outline",
  size = "sm"
}) => {
  const navigate = useNavigate()

  const handleBack = () => {
    if (to) {
      navigate(to)
    } else {
      navigate(-1) // Go back to previous page
    }
  }

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleBack}
      className={`flex items-center space-x-2 ${className}`}
    >
      <ArrowLeft className="h-4 w-4" />
      <span>{label}</span>
    </Button>
  )
}

export default BackButton

