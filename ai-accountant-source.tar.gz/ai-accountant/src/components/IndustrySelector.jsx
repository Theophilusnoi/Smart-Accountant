import React, { useState } from 'react';
import { Building2, Hotel, Hammer, ShoppingCart, Heart, Factory, Briefcase, Home, Users } from 'lucide-react';

const industries = [
  {
    id: 'hospitality',
    name: 'Hospitality & Hotels',
    icon: Hotel,
    description: 'Hotels, restaurants, resorts, and hospitality businesses',
    features: ['Room Revenue Management', 'F&B Cost Control', 'Guest Billing', 'Seasonal Analytics']
  },
  {
    id: 'construction',
    name: 'Construction & Contracting',
    icon: Hammer,
    description: 'Construction companies, contractors, and project-based businesses',
    features: ['Job Costing', 'Progress Billing', 'Equipment Management', 'Subcontractor Tracking']
  },
  {
    id: 'retail',
    name: 'Retail & E-commerce',
    icon: ShoppingCart,
    description: 'Retail stores, e-commerce businesses, and product-based companies',
    features: ['Inventory Management', 'POS Integration', 'Customer Analytics', 'Multi-Channel Sales']
  },
  {
    id: 'healthcare',
    name: 'Healthcare & Medical',
    icon: Heart,
    description: 'Medical practices, clinics, and healthcare providers',
    features: ['Patient Billing', 'Insurance Claims', 'Medical Equipment', 'Compliance Monitoring']
  },
  {
    id: 'manufacturing',
    name: 'Manufacturing',
    icon: Factory,
    description: 'Manufacturing companies and production facilities',
    features: ['Production Costing', 'Raw Material Management', 'Quality Control', 'Supply Chain']
  },
  {
    id: 'professional',
    name: 'Professional Services',
    icon: Briefcase,
    description: 'Law firms, consulting, accounting, and professional service providers',
    features: ['Time & Billing', 'Client Management', 'Project Tracking', 'Trust Accounting']
  },
  {
    id: 'realestate',
    name: 'Real Estate',
    icon: Home,
    description: 'Real estate agencies, property management, and investment companies',
    features: ['Property Management', 'Commission Tracking', 'Tenant Management', 'Market Analysis']
  },
  {
    id: 'nonprofit',
    name: 'Non-Profit',
    icon: Users,
    description: 'Non-profit organizations, charities, and foundations',
    features: ['Fund Accounting', 'Donor Management', 'Grant Tracking', 'Program Accounting']
  }
];

const IndustrySelector = ({ onIndustrySelect, selectedIndustry }) => {
  const [hoveredIndustry, setHoveredIndustry] = useState(null);

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">
          Choose Your Industry
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Select your industry to unlock specialized features, workflows, and compliance tools 
          tailored specifically for your business needs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {industries.map((industry) => {
          const IconComponent = industry.icon;
          const isSelected = selectedIndustry === industry.id;
          const isHovered = hoveredIndustry === industry.id;

          return (
            <div
              key={industry.id}
              className={`
                relative p-6 rounded-xl border-2 cursor-pointer transition-all duration-300
                ${isSelected 
                  ? 'border-blue-500 bg-blue-50 shadow-lg' 
                  : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-md'
                }
              `}
              onClick={() => onIndustrySelect(industry.id)}
              onMouseEnter={() => setHoveredIndustry(industry.id)}
              onMouseLeave={() => setHoveredIndustry(null)}
            >
              {/* Industry Icon */}
              <div className={`
                w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-colors
                ${isSelected 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-100 text-gray-600'
                }
              `}>
                <IconComponent size={24} />
              </div>

              {/* Industry Name */}
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {industry.name}
              </h3>

              {/* Industry Description */}
              <p className="text-sm text-gray-600 mb-4">
                {industry.description}
              </p>

              {/* Key Features */}
              <div className="space-y-1">
                {industry.features.slice(0, 3).map((feature, index) => (
                  <div key={index} className="flex items-center text-xs text-gray-500">
                    <div className="w-1 h-1 bg-blue-400 rounded-full mr-2"></div>
                    {feature}
                  </div>
                ))}
                {industry.features.length > 3 && (
                  <div className="text-xs text-blue-500 font-medium">
                    +{industry.features.length - 3} more features
                  </div>
                )}
              </div>

              {/* Selection Indicator */}
              {isSelected && (
                <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
              )}

              {/* Hover Effect */}
              {isHovered && !isSelected && (
                <div className="absolute inset-0 bg-blue-50 rounded-xl opacity-50 pointer-events-none"></div>
              )}
            </div>
          );
        })}
      </div>

      {/* Custom Industry Option */}
      <div className="mt-8 text-center">
        <div className="inline-flex items-center px-6 py-3 border border-gray-300 rounded-lg bg-white hover:bg-gray-50 cursor-pointer transition-colors">
          <Building2 className="w-5 h-5 text-gray-400 mr-2" />
          <span className="text-gray-600">Don't see your industry? Contact us for custom solutions</span>
        </div>
      </div>

      {selectedIndustry && (
        <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Great choice! You've selected {industries.find(i => i.id === selectedIndustry)?.name}
              </h3>
              <p className="text-gray-600">
                Your platform will be customized with industry-specific features and workflows.
              </p>
            </div>
            <button
              onClick={() => onIndustrySelect(null)}
              className="px-4 py-2 text-sm text-blue-600 hover:text-blue-800 transition-colors"
            >
              Change Selection
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default IndustrySelector;

