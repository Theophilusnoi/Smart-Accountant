import React, { createContext, useContext, useState, useEffect } from 'react';

export const IndustryContext = createContext();

export const useIndustry = () => {
  const context = useContext(IndustryContext);
  if (!context) {
    throw new Error('useIndustry must be used within an IndustryProvider');
  }
  return context;
};

// Industry-specific configurations
const industryConfigs = {
  hospitality: {
    name: 'Hospitality & Hotels',
    chartOfAccounts: [
      { code: '4100', name: 'Room Revenue', type: 'Revenue' },
      { code: '4200', name: 'Food & Beverage Revenue', type: 'Revenue' },
      { code: '4300', name: 'Conference & Events Revenue', type: 'Revenue' },
      { code: '5100', name: 'Room Expenses', type: 'Expense' },
      { code: '5200', name: 'Food & Beverage Costs', type: 'Expense' },
      { code: '5300', name: 'Housekeeping Expenses', type: 'Expense' }
    ],
    dashboardWidgets: [
      'occupancy-rate',
      'adr-revenue',
      'revpar-analysis',
      'fb-revenue',
      'guest-satisfaction',
      'seasonal-trends'
    ],
    reports: [
      'Daily Flash Report',
      'Occupancy Analysis',
      'F&B Cost Report',
      'Revenue Management Report',
      'Guest Analytics',
      'Seasonal Performance'
    ],
    workflows: [
      'guest-checkin',
      'room-service-billing',
      'event-booking',
      'maintenance-request'
    ],
    integrations: ['pms', 'pos', 'revenue-management', 'channel-manager']
  },
  construction: {
    name: 'Construction & Contracting',
    chartOfAccounts: [
      { code: '4100', name: 'Contract Revenue', type: 'Revenue' },
      { code: '4200', name: 'Change Order Revenue', type: 'Revenue' },
      { code: '5100', name: 'Direct Labor', type: 'Expense' },
      { code: '5200', name: 'Materials', type: 'Expense' },
      { code: '5300', name: 'Subcontractor Costs', type: 'Expense' },
      { code: '5400', name: 'Equipment Costs', type: 'Expense' }
    ],
    dashboardWidgets: [
      'job-profitability',
      'project-progress',
      'equipment-utilization',
      'subcontractor-costs',
      'material-costs',
      'safety-metrics'
    ],
    reports: [
      'Job Cost Report',
      'WIP Analysis',
      'Equipment Utilization',
      'Subcontractor Performance',
      'Project Profitability',
      'Change Order Analysis'
    ],
    workflows: [
      'project-setup',
      'material-procurement',
      'progress-billing',
      'change-order-processing'
    ],
    integrations: ['project-management', 'estimating', 'equipment-tracking', 'document-management']
  },
  retail: {
    name: 'Retail & E-commerce',
    chartOfAccounts: [
      { code: '4100', name: 'Product Sales', type: 'Revenue' },
      { code: '4200', name: 'Service Revenue', type: 'Revenue' },
      { code: '5100', name: 'Cost of Goods Sold', type: 'Expense' },
      { code: '5200', name: 'Inventory Adjustments', type: 'Expense' },
      { code: '5300', name: 'Shipping Costs', type: 'Expense' },
      { code: '5400', name: 'Marketing Expenses', type: 'Expense' }
    ],
    dashboardWidgets: [
      'sales-performance',
      'inventory-turnover',
      'customer-metrics',
      'channel-performance',
      'margin-analysis',
      'seasonal-trends'
    ],
    reports: [
      'Sales Analysis',
      'Inventory Report',
      'Customer Analytics',
      'Channel Performance',
      'Margin Analysis',
      'Product Performance'
    ],
    workflows: [
      'inventory-management',
      'order-processing',
      'customer-service',
      'returns-processing'
    ],
    integrations: ['ecommerce', 'pos', 'inventory-management', 'marketing-automation']
  },
  healthcare: {
    name: 'Healthcare & Medical',
    chartOfAccounts: [
      { code: '4100', name: 'Patient Revenue', type: 'Revenue' },
      { code: '4200', name: 'Insurance Revenue', type: 'Revenue' },
      { code: '5100', name: 'Medical Supplies', type: 'Expense' },
      { code: '5200', name: 'Equipment Expenses', type: 'Expense' },
      { code: '5300', name: 'Professional Fees', type: 'Expense' },
      { code: '5400', name: 'Compliance Costs', type: 'Expense' }
    ],
    dashboardWidgets: [
      'patient-volume',
      'insurance-collections',
      'provider-performance',
      'compliance-status',
      'equipment-utilization',
      'patient-satisfaction'
    ],
    reports: [
      'Provider Revenue Report',
      'Insurance Analysis',
      'Patient Aging',
      'Compliance Report',
      'Equipment Utilization',
      'Practice Performance'
    ],
    workflows: [
      'patient-registration',
      'insurance-verification',
      'claim-submission',
      'payment-processing'
    ],
    integrations: ['ehr', 'practice-management', 'medical-billing', 'insurance-verification']
  },
  manufacturing: {
    name: 'Manufacturing',
    chartOfAccounts: [
      { code: '4100', name: 'Product Sales', type: 'Revenue' },
      { code: '5100', name: 'Raw Materials', type: 'Expense' },
      { code: '5200', name: 'Direct Labor', type: 'Expense' },
      { code: '5300', name: 'Manufacturing Overhead', type: 'Expense' },
      { code: '5400', name: 'Quality Control', type: 'Expense' },
      { code: '5500', name: 'Equipment Maintenance', type: 'Expense' }
    ],
    dashboardWidgets: [
      'production-efficiency',
      'quality-metrics',
      'cost-analysis',
      'equipment-performance',
      'supplier-performance',
      'inventory-levels'
    ],
    reports: [
      'Cost of Goods Manufactured',
      'Production Efficiency',
      'Quality Analysis',
      'Supplier Performance',
      'Equipment Utilization',
      'Inventory Analysis'
    ],
    workflows: [
      'production-planning',
      'quality-control',
      'inventory-management',
      'supplier-management'
    ],
    integrations: ['erp', 'mes', 'quality-management', 'supplier-portal']
  },
  professional: {
    name: 'Professional Services',
    chartOfAccounts: [
      { code: '4100', name: 'Professional Fees', type: 'Revenue' },
      { code: '4200', name: 'Retainer Revenue', type: 'Revenue' },
      { code: '5100', name: 'Professional Development', type: 'Expense' },
      { code: '5200', name: 'Client Expenses', type: 'Expense' },
      { code: '5300', name: 'Technology Costs', type: 'Expense' },
      { code: '5400', name: 'Marketing Expenses', type: 'Expense' }
    ],
    dashboardWidgets: [
      'billable-hours',
      'client-profitability',
      'utilization-rates',
      'project-performance',
      'revenue-recognition',
      'client-satisfaction'
    ],
    reports: [
      'Time and Billing',
      'Client Profitability',
      'Staff Utilization',
      'Project Performance',
      'Revenue Recognition',
      'Trust Account Report'
    ],
    workflows: [
      'client-onboarding',
      'time-tracking',
      'project-management',
      'billing-process'
    ],
    integrations: ['time-tracking', 'project-management', 'document-management', 'crm']
  },
  realestate: {
    name: 'Real Estate',
    chartOfAccounts: [
      { code: '4100', name: 'Commission Revenue', type: 'Revenue' },
      { code: '4200', name: 'Property Management Revenue', type: 'Revenue' },
      { code: '4300', name: 'Rental Income', type: 'Revenue' },
      { code: '5100', name: 'Marketing Expenses', type: 'Expense' },
      { code: '5200', name: 'Property Maintenance', type: 'Expense' },
      { code: '5300', name: 'Professional Fees', type: 'Expense' }
    ],
    dashboardWidgets: [
      'property-performance',
      'commission-tracking',
      'occupancy-rates',
      'maintenance-costs',
      'market-analysis',
      'client-pipeline'
    ],
    reports: [
      'Property Performance',
      'Commission Analysis',
      'Rental Income Report',
      'Maintenance Cost Analysis',
      'Market Comparison',
      'Client Pipeline Report'
    ],
    workflows: [
      'property-listing',
      'tenant-management',
      'maintenance-scheduling',
      'commission-processing'
    ],
    integrations: ['mls', 'property-management', 'crm', 'marketing-platforms']
  },
  nonprofit: {
    name: 'Non-Profit',
    chartOfAccounts: [
      { code: '4100', name: 'Donations', type: 'Revenue' },
      { code: '4200', name: 'Grant Revenue', type: 'Revenue' },
      { code: '4300', name: 'Program Revenue', type: 'Revenue' },
      { code: '5100', name: 'Program Expenses', type: 'Expense' },
      { code: '5200', name: 'Administrative Expenses', type: 'Expense' },
      { code: '5300', name: 'Fundraising Expenses', type: 'Expense' }
    ],
    dashboardWidgets: [
      'fund-balances',
      'donor-metrics',
      'grant-compliance',
      'program-efficiency',
      'fundraising-roi',
      'volunteer-hours'
    ],
    reports: [
      'Statement of Activities',
      'Functional Expense Report',
      'Grant Compliance Report',
      'Donor Analysis',
      'Program Efficiency',
      'Board Financial Report'
    ],
    workflows: [
      'donation-processing',
      'grant-management',
      'volunteer-coordination',
      'program-tracking'
    ],
    integrations: ['donor-management', 'grant-tracking', 'volunteer-management', 'fundraising-platforms']
  }
};

export const IndustryProvider = ({ children }) => {
  const [selectedIndustry, setSelectedIndustry] = useState(null);
  const [industryConfig, setIndustryConfig] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Load industry from localStorage on mount
  useEffect(() => {
    const savedIndustry = localStorage.getItem('selectedIndustry');
    if (savedIndustry && industryConfigs[savedIndustry]) {
      setSelectedIndustry(savedIndustry);
      setIndustryConfig(industryConfigs[savedIndustry]);
    }
  }, []);

  const selectIndustry = async (industryId) => {
    setIsLoading(true);
    
    try {
      if (industryId && industryConfigs[industryId]) {
        setSelectedIndustry(industryId);
        setIndustryConfig(industryConfigs[industryId]);
        localStorage.setItem('selectedIndustry', industryId);
      } else {
        setSelectedIndustry(null);
        setIndustryConfig(null);
        localStorage.removeItem('selectedIndustry');
      }
    } catch (error) {
      console.error('Error selecting industry:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getIndustryFeature = (featureName) => {
    if (!industryConfig) return null;
    return industryConfig[featureName] || null;
  };

  const isFeatureEnabled = (featureName) => {
    if (!industryConfig) return false;
    return industryConfig.dashboardWidgets?.includes(featureName) || 
           industryConfig.workflows?.includes(featureName) ||
           industryConfig.integrations?.includes(featureName);
  };

  const getChartOfAccounts = () => {
    return industryConfig?.chartOfAccounts || [];
  };

  const getDashboardWidgets = () => {
    return industryConfig?.dashboardWidgets || [];
  };

  const getAvailableReports = () => {
    return industryConfig?.reports || [];
  };

  const getWorkflows = () => {
    return industryConfig?.workflows || [];
  };

  const getIntegrations = () => {
    return industryConfig?.integrations || [];
  };

  const value = {
    selectedIndustry,
    industryConfig,
    isLoading,
    selectIndustry,
    getIndustryFeature,
    isFeatureEnabled,
    getChartOfAccounts,
    getDashboardWidgets,
    getAvailableReports,
    getWorkflows,
    getIntegrations,
    industryConfigs
  };

  return (
    <IndustryContext.Provider value={value}>
      {children}
    </IndustryContext.Provider>
  );
};

export default IndustryContext;

