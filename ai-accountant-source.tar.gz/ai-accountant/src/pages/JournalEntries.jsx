import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { FileText, Plus, Edit, Trash2 } from 'lucide-react'

const JournalEntries = () => {
  const journalEntries = [
    {
      id: 1,
      date: '2025-01-10',
      reference: 'JE001',
      description: 'Client payment received',
      debitAccount: 'Cash',
      creditAccount: 'Accounts Receivable',
      amount: 5000.00,
      status: 'posted'
    },
    {
      id: 2,
      date: '2025-01-09',
      reference: 'JE002',
      description: 'Office supplies purchase',
      debitAccount: 'Office Expenses',
      creditAccount: 'Cash',
      amount: 234.50,
      status: 'posted'
    },
    {
      id: 3,
      date: '2025-01-08',
      reference: 'JE003',
      description: 'Vendor invoice received',
      debitAccount: 'Office Expenses',
      creditAccount: 'Accounts Payable',
      amount: 1500.00,
      status: 'draft'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Journal Entries</h1>
            <p className="text-gray-600 mt-1">Manage your accounting journal entries</p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Entry
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5" />
              <span>All Journal Entries</span>
            </CardTitle>
            <CardDescription>View and manage your journal entries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Date</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Reference</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Description</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Debit Account</th>
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Credit Account</th>
                    <th className="text-right py-3 px-2 font-medium text-gray-600">Amount</th>
                    <th className="text-center py-3 px-2 font-medium text-gray-600">Status</th>
                    <th className="text-center py-3 px-2 font-medium text-gray-600">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {journalEntries.map((entry) => (
                    <tr key={entry.id} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2 text-sm text-gray-600">{entry.date}</td>
                      <td className="py-3 px-2 font-medium text-blue-600">{entry.reference}</td>
                      <td className="py-3 px-2 text-sm text-gray-900">{entry.description}</td>
                      <td className="py-3 px-2 text-sm text-gray-600">{entry.debitAccount}</td>
                      <td className="py-3 px-2 text-sm text-gray-600">{entry.creditAccount}</td>
                      <td className="py-3 px-2 text-right font-medium">${entry.amount.toFixed(2)}</td>
                      <td className="py-3 px-2 text-center">
                        <Badge variant={entry.status === 'posted' ? 'default' : 'secondary'}>
                          {entry.status}
                        </Badge>
                      </td>
                      <td className="py-3 px-2 text-center">
                        <div className="flex justify-center space-x-1">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default JournalEntries

