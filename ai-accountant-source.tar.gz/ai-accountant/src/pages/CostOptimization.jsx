import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { TrendingUp, Lightbulb, DollarSign } from 'lucide-react'

const CostOptimization = () => {
  const suggestions = [
    {
      title: 'Optimize Software Subscriptions',
      description: 'You have 3 unused software licenses that could save $150/month',
      savings: '$1,800/year',
      priority: 'high',
      category: 'Software'
    },
    {
      title: 'Negotiate Vendor Contracts',
      description: 'Your office supply costs are 23% above industry average',
      savings: '$450/month',
      priority: 'medium',
      category: 'Supplies'
    },
    {
      title: 'Energy Efficiency Upgrade',
      description: 'LED lighting upgrade could reduce electricity costs',
      savings: '$200/month',
      priority: 'low',
      category: 'Utilities'
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Cost Optimization</h1>
          <p className="text-gray-600 mt-1">AI-powered suggestions to reduce your expenses</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">$2,450</div>
                  <div className="text-sm text-gray-600">Potential Monthly Savings</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">$29,400</div>
                  <div className="text-sm text-gray-600">Annual Savings Potential</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <Lightbulb className="h-8 w-8 text-yellow-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">{suggestions.length}</div>
                  <div className="text-sm text-gray-600">Active Suggestions</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>AI Recommendations</CardTitle>
            <CardDescription>Smart cost-saving opportunities identified by AI</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-medium text-gray-900">{suggestion.title}</h4>
                        <Badge 
                          variant={suggestion.priority === 'high' ? 'destructive' : suggestion.priority === 'medium' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {suggestion.priority}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {suggestion.category}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{suggestion.description}</p>
                    </div>
                    <div className="text-right ml-4">
                      <div className="font-semibold text-green-600">{suggestion.savings}</div>
                      <div className="text-xs text-gray-500">potential savings</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default CostOptimization

