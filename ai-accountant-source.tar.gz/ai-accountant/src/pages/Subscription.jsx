import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Check, 
  CreditCard, 
  Crown, 
  Zap, 
  Shield,
  Users,
  BarChart3,
  Headphones,
  Settings,
  Calendar,
  AlertTriangle
} from 'lucide-react'
import { useSubscription } from '../hooks/useSubscription.jsx'

const Subscription = () => {
  const { 
    subscription, 
    loading, 
    plans, 
    createCheckoutSession, 
    cancelSubscription, 
    getCurrentPlan,
    canAccessFeature 
  } = useSubscription()
  
  const [selectedPlan, setSelectedPlan] = useState(null)
  const currentPlan = getCurrentPlan()

  const handleUpgrade = async (planId) => {
    setSelectedPlan(planId)
    const result = await createCheckoutSession(planId)
    if (!result.success) {
      alert('Failed to start checkout process')
    }
    setSelectedPlan(null)
  }

  const handleCancel = async () => {
    if (confirm('Are you sure you want to cancel your subscription?')) {
      const result = await cancelSubscription()
      if (result.success) {
        alert('Subscription canceled successfully')
      } else {
        alert('Failed to cancel subscription')
      }
    }
  }

  const getUsagePercentage = (feature) => {
    // Mock usage data
    switch (feature) {
      case 'ocr_uploads':
        return currentPlan.id === 'free' ? 70 : 25
      case 'users':
        return 40
      case 'storage':
        return 60
      default:
        return 0
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900">Subscription Plans</h1>
          <p className="text-gray-600 mt-1">Choose the plan that fits your business needs</p>
        </div>

        {/* Current Plan Status */}
        {subscription && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CreditCard className="h-5 w-5" />
                <span>Current Plan</span>
              </CardTitle>
              <CardDescription>Your current subscription details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Badge variant={subscription.status === 'active' ? 'default' : 'secondary'}>
                      {subscription.status}
                    </Badge>
                    {currentPlan.id === 'pro' && <Crown className="h-4 w-4 text-yellow-500" />}
                    {currentPlan.id === 'enterprise' && <Shield className="h-4 w-4 text-purple-500" />}
                  </div>
                  <div className="font-medium text-lg">{currentPlan.name}</div>
                  <div className="text-sm text-gray-600">
                    ${currentPlan.price}/month
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-600">Billing Period</div>
                  <div className="text-sm">
                    {formatDate(subscription.current_period_start)} - {formatDate(subscription.current_period_end)}
                  </div>
                  <div className="text-sm text-gray-600">
                    Next billing: {formatDate(subscription.current_period_end)}
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium text-gray-600">Actions</div>
                  <div className="space-y-2">
                    {currentPlan.id === 'free' ? (
                      <Button size="sm" onClick={() => handleUpgrade('pro')}>
                        <Zap className="h-4 w-4 mr-2" />
                        Upgrade to Pro
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" onClick={handleCancel}>
                        Cancel Subscription
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Usage Overview */}
        {currentPlan.id === 'free' && (
          <Card>
            <CardHeader>
              <CardTitle>Usage Overview</CardTitle>
              <CardDescription>Your current usage against plan limits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>OCR Uploads</span>
                    <span>7/10</span>
                  </div>
                  <Progress value={getUsagePercentage('ocr_uploads')} />
                  <div className="text-xs text-gray-600">
                    {getUsagePercentage('ocr_uploads') > 80 && (
                      <div className="flex items-center text-orange-600">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Approaching limit
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Users</span>
                    <span>1/1</span>
                  </div>
                  <Progress value={100} />
                  <div className="text-xs text-gray-600">Maximum reached</div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Storage</span>
                    <span>1.2GB/2GB</span>
                  </div>
                  <Progress value={getUsagePercentage('storage')} />
                  <div className="text-xs text-gray-600">60% used</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Plan Comparison */}
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${
                plan.id === 'pro' ? 'border-blue-500 shadow-lg' : ''
              } ${
                plan.id === currentPlan.id ? 'ring-2 ring-green-500' : ''
              }`}
            >
              {plan.id === 'pro' && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">
                  Most Popular
                </Badge>
              )}
              {plan.id === currentPlan.id && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-600">
                  Current Plan
                </Badge>
              )}
              
              <CardHeader className="text-center">
                <div className="flex justify-center mb-2">
                  {plan.id === 'free' && <Users className="h-8 w-8 text-gray-600" />}
                  {plan.id === 'pro' && <Crown className="h-8 w-8 text-yellow-500" />}
                  {plan.id === 'enterprise' && <Shield className="h-8 w-8 text-purple-500" />}
                </div>
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <div className="text-3xl font-bold text-gray-900">
                  ${plan.price}<span className="text-lg text-gray-600">/month</span>
                </div>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className="w-full" 
                  variant={plan.id === currentPlan.id ? 'outline' : plan.id === 'pro' ? 'default' : 'outline'}
                  disabled={plan.id === currentPlan.id || loading || selectedPlan === plan.id}
                  onClick={() => handleUpgrade(plan.id)}
                >
                  {loading && selectedPlan === plan.id ? (
                    'Processing...'
                  ) : plan.id === currentPlan.id ? (
                    'Current Plan'
                  ) : plan.id === 'free' ? (
                    'Downgrade'
                  ) : (
                    'Choose Plan'
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feature Comparison */}
        <Card>
          <CardHeader>
            <CardTitle>Feature Comparison</CardTitle>
            <CardDescription>Detailed comparison of features across all plans</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Feature</th>
                    <th className="text-center py-3 px-2 font-medium text-gray-600">Free</th>
                    <th className="text-center py-3 px-2 font-medium text-gray-600">Pro</th>
                    <th className="text-center py-3 px-2 font-medium text-gray-600">Enterprise</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <Users className="h-4 w-4" />
                      <span>Users</span>
                    </td>
                    <td className="py-3 px-2 text-center">1</td>
                    <td className="py-3 px-2 text-center">Unlimited</td>
                    <td className="py-3 px-2 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <BarChart3 className="h-4 w-4" />
                      <span>OCR Uploads</span>
                    </td>
                    <td className="py-3 px-2 text-center">10/month</td>
                    <td className="py-3 px-2 text-center">Unlimited</td>
                    <td className="py-3 px-2 text-center">Unlimited</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <Zap className="h-4 w-4" />
                      <span>AI Cost Suggestions</span>
                    </td>
                    <td className="py-3 px-2 text-center">❌</td>
                    <td className="py-3 px-2 text-center">✅</td>
                    <td className="py-3 px-2 text-center">✅</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <BarChart3 className="h-4 w-4" />
                      <span>Advanced Reports</span>
                    </td>
                    <td className="py-3 px-2 text-center">Basic</td>
                    <td className="py-3 px-2 text-center">Full</td>
                    <td className="py-3 px-2 text-center">Enterprise</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <Headphones className="h-4 w-4" />
                      <span>Support</span>
                    </td>
                    <td className="py-3 px-2 text-center">Email</td>
                    <td className="py-3 px-2 text-center">Priority</td>
                    <td className="py-3 px-2 text-center">Dedicated</td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-2 flex items-center space-x-2">
                      <Settings className="h-4 w-4" />
                      <span>Custom Integrations</span>
                    </td>
                    <td className="py-3 px-2 text-center">❌</td>
                    <td className="py-3 px-2 text-center">❌</td>
                    <td className="py-3 px-2 text-center">✅</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Billing History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>Billing History</span>
            </CardTitle>
            <CardDescription>Your payment history and invoices</CardDescription>
          </CardHeader>
          <CardContent>
            {currentPlan.id === 'free' ? (
              <div className="text-center py-8">
                <CreditCard className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No billing history available for free plan</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <div className="font-medium">Pro Plan - January 2025</div>
                    <div className="text-sm text-gray-600">Paid on Jan 1, 2025</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">$19.00</div>
                    <Badge variant="default">Paid</Badge>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default Subscription

