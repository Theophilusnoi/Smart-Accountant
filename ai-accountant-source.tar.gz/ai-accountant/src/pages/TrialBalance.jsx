import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { BarChart3, CheckCircle, AlertTriangle } from 'lucide-react'

const TrialBalance = () => {
  const trialBalanceData = [
    { account: 'Cash', debit: 15000.00, credit: 0 },
    { account: 'Accounts Receivable', debit: 8500.00, credit: 0 },
    { account: 'Office Equipment', debit: 12000.00, credit: 0 },
    { account: 'Accounts Payable', debit: 0, credit: 3500.00 },
    { account: 'Revenue', debit: 0, credit: 45000.00 },
    { account: 'Office Expenses', debit: 1234.50, credit: 0 },
    { account: 'Software Expenses', debit: 299.99, credit: 0 }
  ]

  const totalDebits = trialBalanceData.reduce((sum, item) => sum + item.debit, 0)
  const totalCredits = trialBalanceData.reduce((sum, item) => sum + item.credit, 0)
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Trial Balance</h1>
          <p className="text-gray-600 mt-1">Verify the arithmetical accuracy of your ledger</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">${totalDebits.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">Total Debits</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">${totalCredits.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">Total Credits</div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                {isBalanced ? (
                  <CheckCircle className="h-8 w-8 text-green-600" />
                ) : (
                  <AlertTriangle className="h-8 w-8 text-red-600" />
                )}
                <div>
                  <Badge variant={isBalanced ? 'default' : 'destructive'} className="mb-1">
                    {isBalanced ? 'Balanced' : 'Unbalanced'}
                  </Badge>
                  <div className="text-sm text-gray-600">Status</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Trial Balance Report</CardTitle>
            <CardDescription>As of January 11, 2025</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-2 font-medium text-gray-600">Account</th>
                    <th className="text-right py-3 px-2 font-medium text-gray-600">Debit</th>
                    <th className="text-right py-3 px-2 font-medium text-gray-600">Credit</th>
                  </tr>
                </thead>
                <tbody>
                  {trialBalanceData.map((item, index) => (
                    <tr key={index} className="border-b hover:bg-gray-50">
                      <td className="py-3 px-2 font-medium text-gray-900">{item.account}</td>
                      <td className="py-3 px-2 text-right">
                        {item.debit > 0 ? `$${item.debit.toLocaleString()}` : '-'}
                      </td>
                      <td className="py-3 px-2 text-right">
                        {item.credit > 0 ? `$${item.credit.toLocaleString()}` : '-'}
                      </td>
                    </tr>
                  ))}
                  <tr className="border-t-2 border-gray-300 font-bold">
                    <td className="py-3 px-2 text-gray-900">Total</td>
                    <td className="py-3 px-2 text-right text-gray-900">${totalDebits.toLocaleString()}</td>
                    <td className="py-3 px-2 text-right text-gray-900">${totalCredits.toLocaleString()}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default TrialBalance

