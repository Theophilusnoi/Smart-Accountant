import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useIndustry } from '../contexts/IndustryContext'
import IndustryDashboard from '../components/IndustryDashboard'
import PageHeader from '../components/PageHeader'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Upload, 
  FileText, 
  BarChart3, 
  Calculator,
  CheckCircle,
  AlertTriangle,
  Lightbulb,
  CreditCard,
  Building,
  Clock,
  Target,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Eye,
  Download
} from 'lucide-react'
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  AreaChart,
  Area
} from 'recharts'
import { useAuth } from '../hooks/useAuth.jsx'

const Dashboard = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const { selectedIndustry } = useIndustry()
  const [selectedPeriod, setSelectedPeriod] = useState('This Month')

  // Check if user needs to complete industry onboarding
  useEffect(() => {
    if (!selectedIndustry) {
      navigate('/onboarding')
    }
  }, [selectedIndustry, navigate])

  // Handle AI Insight actions
  const handleAIInsightAction = (suggestionId, action) => {
    switch (suggestionId) {
      case 1: // Optimize Software Subscriptions
        // Navigate to subscription management or show modal
        alert(`Action: ${action}\n\nThis would typically:\n• Open subscription management page\n• Show detailed analysis of unused licenses\n• Provide cancellation options\n• Track savings progress`)
        break
      case 2: // Negotiate Vendor Contracts
        // Navigate to vendor management or show contact info
        alert(`Action: ${action}\n\nThis would typically:\n• Open vendor management page\n• Show contact information for suppliers\n• Provide negotiation templates\n• Track cost reduction progress`)
        break
      case 3: // Invoice Follow-up Needed
        // Navigate to overdue invoices or send reminders
        alert(`Action: ${action}\n\nThis would typically:\n• Open overdue invoices page\n• Send automated reminder emails\n• Show follow-up templates\n• Track collection progress`)
        break
      default:
        alert(`Action: ${action}\n\nThis feature is being implemented.`)
    }
  }

  // Enhanced financial metrics with more detail
  const metrics = [
    {
      title: 'Total Revenue',
      value: '$45,231.89',
      change: '+20.1% from last month',
      trend: 'up',
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      details: 'Last 30 days'
    },
    {
      title: 'Total Expenses',
      value: '$12,234.56',
      change: '-4.3% from last month',
      trend: 'down',
      icon: TrendingDown,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      details: 'Last 30 days'
    },
    {
      title: 'Net Profit',
      value: '$32,997.33',
      change: '+12.5% from last month',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      details: 'Profit margin: 73%'
    },
    {
      title: 'Cash Flow',
      value: '$18,456.78',
      change: '+8.2% from last month',
      trend: 'up',
      icon: Target,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      details: 'Available cash'
    }
  ]

  // Cash flow data for chart
  const cashFlowData = [
    { month: 'Jan', income: 35000, expenses: 12000, net: 23000 },
    { month: 'Feb', income: 42000, expenses: 15000, net: 27000 },
    { month: 'Mar', income: 38000, expenses: 11000, net: 27000 },
    { month: 'Apr', income: 45000, expenses: 13000, net: 32000 },
    { month: 'May', income: 48000, expenses: 14000, net: 34000 },
    { month: 'Jun', income: 52000, expenses: 16000, net: 36000 }
  ]

  // Expense breakdown data
  const expenseData = [
    { name: 'Office Supplies', value: 2500, color: '#8884d8' },
    { name: 'Software', value: 1800, color: '#82ca9d' },
    { name: 'Marketing', value: 3200, color: '#ffc658' },
    { name: 'Travel', value: 1500, color: '#ff7300' },
    { name: 'Utilities', value: 800, color: '#00ff88' },
    { name: 'Other', value: 2434, color: '#ff8888' }
  ]

  // Recent transactions with more detail
  const recentTransactions = [
    {
      id: 1,
      description: 'Office Supplies - Staples',
      category: 'Office Expenses',
      date: '2025-01-10',
      amount: -234.50,
      status: 'completed',
      type: 'expense',
      account: 'Business Checking'
    },
    {
      id: 2,
      description: 'Client Payment - ABC Corp',
      category: 'Revenue',
      date: '2025-01-09',
      amount: 5000.00,
      status: 'completed',
      type: 'income',
      account: 'Business Checking'
    },
    {
      id: 3,
      description: 'Software Subscription - Adobe',
      category: 'Software',
      date: '2025-01-08',
      amount: -52.99,
      status: 'completed',
      type: 'expense',
      account: 'Business Credit Card'
    },
    {
      id: 4,
      description: 'Consulting Fee - XYZ Ltd',
      category: 'Revenue',
      date: '2025-01-07',
      amount: 2500.00,
      status: 'completed',
      type: 'income',
      account: 'Business Checking'
    },
    {
      id: 5,
      description: 'Marketing Campaign - Google Ads',
      category: 'Marketing',
      date: '2025-01-06',
      amount: -450.00,
      status: 'pending',
      type: 'expense',
      account: 'Business Credit Card'
    }
  ]

  // Outstanding invoices
  const outstandingInvoices = [
    { id: 'INV-001', client: 'ABC Corporation', amount: 2500.00, dueDate: '2025-01-15', status: 'overdue' },
    { id: 'INV-002', client: 'XYZ Industries', amount: 1800.00, dueDate: '2025-01-20', status: 'pending' },
    { id: 'INV-003', client: 'Tech Solutions', amount: 3200.00, dueDate: '2025-01-25', status: 'pending' }
  ]

  // AI suggestions with more detail
  const aiSuggestions = [
    {
      id: 1,
      title: 'Optimize Software Subscriptions',
      description: 'You have 3 unused software licenses that could save $150/month',
      priority: 'high',
      savings: '$1,800/year',
      icon: Lightbulb,
      action: 'Review subscriptions'
    },
    {
      id: 2,
      title: 'Negotiate Vendor Contracts',
      description: 'Your office supply costs are 23% above industry average',
      priority: 'medium',
      savings: '$450/month',
      icon: AlertTriangle,
      action: 'Contact vendors'
    },
    {
      id: 3,
      title: 'Invoice Follow-up Needed',
      description: '2 invoices are overdue totaling $4,300',
      priority: 'high',
      savings: 'Improve cash flow',
      icon: Clock,
      action: 'Send reminders'
    }
  ]

  // Quick actions with more options
  const quickActions = [
    { name: 'Create Invoice', icon: FileText, href: '/invoices/new', description: 'Bill your clients', color: 'bg-blue-500' },
    { name: 'Add Expense', icon: Upload, href: '/expenses/new', description: 'Record expenses', color: 'bg-green-500' },
    { name: 'View Reports', icon: BarChart3, href: '/financial-reports', description: 'Financial insights', color: 'bg-purple-500' },
    { name: 'Bank Reconciliation', icon: Building, href: '/banking', description: 'Match transactions', color: 'bg-orange-500' },
    { name: 'Manage Projects', icon: Target, href: '/projects', description: 'Track profitability', color: 'bg-indigo-500' },
    { name: 'Run Payroll', icon: Users, href: '/payroll', description: 'Pay employees', color: 'bg-pink-500' }
  ]

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Page Header with Back Button */}
      <PageHeader 
        title={`Welcome back, ${user?.user_metadata?.first_name || 'User'}!`}
        subtitle="Here's what's happening with your business today."
        showBackButton={false}
      >
        <div className="flex items-center space-x-2 mb-4">
          <CheckCircle className="h-5 w-5 text-green-500" />
          <span className="text-sm text-green-600 font-medium">All systems operational</span>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" className="flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
          <Button className="flex items-center">
            <Plus className="h-4 w-4 mr-2" />
            Quick Add
          </Button>
        </div>
      </PageHeader>

      {/* Enhanced Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((metric) => (
          <Card key={metric.title} className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {metric.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${metric.bgColor}`}>
                <metric.icon className={`h-4 w-4 ${metric.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metric.value}</div>
              <p className={`text-xs ${metric.trend === 'up' ? 'text-green-600' : 'text-red-600'} flex items-center mt-1`}>
                {metric.trend === 'up' ? (
                  <ArrowUpRight className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDownRight className="h-3 w-3 mr-1" />
                )}
                {metric.change}
              </p>
              <p className="text-xs text-gray-500 mt-1">{metric.details}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Industry-Specific Dashboard */}
      <IndustryDashboard />

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cash Flow Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="h-5 w-5 mr-2" />
              Cash Flow Trends
            </CardTitle>
            <p className="text-sm text-gray-600">Income vs Expenses over time</p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={cashFlowData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, '']} />
                <Area type="monotone" dataKey="income" stackId="1" stroke="#10b981" fill="#10b981" fillOpacity={0.6} />
                <Area type="monotone" dataKey="expenses" stackId="2" stroke="#ef4444" fill="#ef4444" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Expense Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="h-5 w-5 mr-2" />
              Expense Breakdown
            </CardTitle>
            <p className="text-sm text-gray-600">Where your money is going</p>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <RechartsPieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Amount']} />
              </RechartsPieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Transactions */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Recent Transactions
                </CardTitle>
                <p className="text-sm text-gray-600">Your latest financial activities</p>
              </div>
              <Button variant="outline" size="sm">
                <Eye className="h-4 w-4 mr-2" />
                View All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((transaction) => (
                <div key={transaction.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{transaction.description}</h4>
                    <p className="text-sm text-gray-600">{transaction.category} • {transaction.account}</p>
                    <p className="text-xs text-gray-500">{transaction.date}</p>
                  </div>
                  <div className="text-right">
                    <span className={`font-semibold ${transaction.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
                    </span>
                    <div className="flex items-center mt-1">
                      <CheckCircle className="h-3 w-3 text-green-500 mr-1" />
                      <span className="text-xs text-gray-500 capitalize">{transaction.status}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* AI Insights & Outstanding Invoices */}
        <div className="space-y-6">
          {/* Outstanding Invoices */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="h-5 w-5 mr-2" />
                Outstanding Invoices
              </CardTitle>
              <p className="text-sm text-gray-600">Invoices awaiting payment</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {outstandingInvoices.map((invoice) => (
                  <div key={invoice.id} className="p-3 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm">{invoice.id}</span>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        invoice.status === 'overdue' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {invoice.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{invoice.client}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-semibold text-green-600">${invoice.amount.toFixed(2)}</span>
                      <span className="text-xs text-gray-500">Due: {invoice.dueDate}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI Cost Optimization */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lightbulb className="h-5 w-5 mr-2" />
                AI Insights
              </CardTitle>
              <p className="text-sm text-gray-600">Smart suggestions to improve your business</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiSuggestions.map((suggestion) => (
                  <div key={suggestion.id} className="p-3 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-sm">{suggestion.title}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        suggestion.priority === 'high' ? 'bg-red-100 text-red-700' :
                        suggestion.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {suggestion.priority}
                      </span>
                    </div>
                    <p className="text-xs text-gray-600 mb-2">{suggestion.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-green-600">{suggestion.savings}</span>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="text-xs hover:bg-blue-50 hover:text-blue-600 transition-colors"
                        onClick={() => handleAIInsightAction(suggestion.id, suggestion.action)}
                      >
                        {suggestion.action}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <p className="text-sm text-gray-600">Common tasks to manage your business</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {quickActions.map((action) => (
              <Button
                key={action.name}
                variant="outline"
                className="h-auto p-4 flex flex-col items-center space-y-2 hover:shadow-md transition-shadow"
                asChild
              >
                <a href={action.href}>
                  <div className={`p-2 rounded-lg ${action.color} text-white`}>
                    <action.icon className="h-6 w-6" />
                  </div>
                  <span className="font-medium text-center">{action.name}</span>
                  <span className="text-xs text-gray-500 text-center">{action.description}</span>
                </a>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default Dashboard

