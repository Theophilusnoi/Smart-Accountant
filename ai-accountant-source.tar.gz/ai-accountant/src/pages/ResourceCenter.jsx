import React, { useState, useContext } from 'react';
import { Search, Calendar, User, ArrowRight, BookOpen, TrendingUp, FileText, Star } from 'lucide-react';
import { IndustryContext } from '../contexts/IndustryContext';

const ResourceCenter = () => {
  const { selectedIndustry } = useContext(IndustryContext);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data for demonstration
  const articles = [
    {
      id: 1,
      title: 'AI-Powered Bookkeeping: The Future of Small Business Accounting',
      excerpt: 'Discover how artificial intelligence is revolutionizing bookkeeping processes and reducing manual work by up to 90%.',
      category: 'Technology',
      author: 'Sarah Johnson',
      date: '2024-01-15',
      readTime: '5 min read',
      image: '/api/placeholder/400/250',
      featured: true,
      tags: ['AI', 'Automation', 'Small Business']
    },
    {
      id: 2,
      title: 'Tax Planning Strategies for 2024: What Every Business Owner Should Know',
      excerpt: 'Essential tax planning strategies to maximize deductions and minimize liability for the upcoming tax season.',
      category: 'Tax Planning',
      author: 'Michael Chen',
      date: '2024-01-12',
      readTime: '8 min read',
      image: '/api/placeholder/400/250',
      featured: false,
      tags: ['Tax Planning', 'Business Strategy', 'Compliance']
    },
    {
      id: 3,
      title: 'Cash Flow Management: 7 Proven Strategies for Better Financial Health',
      excerpt: 'Learn practical techniques to improve cash flow management and ensure your business stays financially healthy.',
      category: 'Financial Management',
      author: 'Emily Rodriguez',
      date: '2024-01-10',
      readTime: '6 min read',
      image: '/api/placeholder/400/250',
      featured: false,
      tags: ['Cash Flow', 'Financial Health', 'Business Growth']
    },
    {
      id: 4,
      title: 'Industry Spotlight: Accounting Trends in Hospitality & Hotels',
      excerpt: 'Specialized accounting considerations and trends specific to the hospitality industry.',
      category: 'Industry Insights',
      author: 'David Park',
      date: '2024-01-08',
      readTime: '7 min read',
      image: '/api/placeholder/400/250',
      featured: false,
      tags: ['Hospitality', 'Industry Trends', 'Revenue Management']
    },
    {
      id: 5,
      title: 'Construction Accounting: Job Costing Best Practices',
      excerpt: 'Master job costing techniques to improve profitability and project management in construction businesses.',
      category: 'Industry Insights',
      author: 'Lisa Thompson',
      date: '2024-01-05',
      readTime: '9 min read',
      image: '/api/placeholder/400/250',
      featured: false,
      tags: ['Construction', 'Job Costing', 'Project Management']
    },
    {
      id: 6,
      title: 'Retail Inventory Management: Optimizing Stock Levels with AI',
      excerpt: 'How AI-powered inventory management can reduce costs and improve customer satisfaction in retail.',
      category: 'Technology',
      author: 'Alex Kumar',
      date: '2024-01-03',
      readTime: '6 min read',
      image: '/api/placeholder/400/250',
      featured: false,
      tags: ['Retail', 'Inventory', 'AI Technology']
    }
  ];

  const categories = [
    { id: 'all', label: 'All Articles', count: articles.length },
    { id: 'Technology', label: 'Technology', count: articles.filter(a => a.category === 'Technology').length },
    { id: 'Tax Planning', label: 'Tax Planning', count: articles.filter(a => a.category === 'Tax Planning').length },
    { id: 'Financial Management', label: 'Financial Management', count: articles.filter(a => a.category === 'Financial Management').length },
    { id: 'Industry Insights', label: 'Industry Insights', count: articles.filter(a => a.category === 'Industry Insights').length }
  ];

  const featuredResources = [
    {
      id: 1,
      title: 'Small Business Tax Guide 2024',
      description: 'Comprehensive guide covering all tax requirements for small businesses',
      type: 'PDF Guide',
      downloads: '2.3k'
    },
    {
      id: 2,
      title: 'Financial Planning Template',
      description: 'Excel template for annual financial planning and budgeting',
      type: 'Excel Template',
      downloads: '1.8k'
    },
    {
      id: 3,
      title: 'Industry Benchmarking Report',
      description: 'Compare your business performance against industry standards',
      type: 'Report',
      downloads: '1.5k'
    }
  ];

  const filteredArticles = articles.filter(article => {
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const featuredArticle = articles.find(article => article.featured);
  const regularArticles = filteredArticles.filter(article => !article.featured);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Resource Center</h1>
            <p className="text-gray-600 text-lg">Industry insights, best practices, and educational content to grow your business</p>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search articles, guides, and resources..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.label} ({category.count})
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Featured Article */}
            {featuredArticle && selectedCategory === 'all' && (
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="relative">
                  <img 
                    src="/api/placeholder/800/400" 
                    alt={featuredArticle.title}
                    className="w-full h-64 object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                      <Star className="h-3 w-3 mr-1" />
                      Featured
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                      {featuredArticle.category}
                    </span>
                    <div className="flex items-center space-x-1">
                      <User className="h-3 w-3" />
                      <span>{featuredArticle.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>{featuredArticle.date}</span>
                    </div>
                    <span>{featuredArticle.readTime}</span>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 mb-3">{featuredArticle.title}</h2>
                  <p className="text-gray-600 mb-4">{featuredArticle.excerpt}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-2">
                      {featuredArticle.tags.map((tag, index) => (
                        <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                          {tag}
                        </span>
                      ))}
                    </div>
                    <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 font-medium">
                      <span>Read More</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Articles Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {regularArticles.map((article) => (
                <div key={article.id} className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow">
                  <img 
                    src="/api/placeholder/400/200" 
                    alt={article.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                      <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                        {article.category}
                      </span>
                      <span>{article.readTime}</span>
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">{article.title}</h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">{article.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-sm text-gray-500">
                        <User className="h-3 w-3" />
                        <span>{article.author}</span>
                        <span>•</span>
                        <span>{article.date}</span>
                      </div>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Read More
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* No Results */}
            {filteredArticles.length === 0 && (
              <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No articles found</h3>
                <p className="text-gray-600">Try adjusting your search terms or category filter.</p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Featured Resources */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Featured Resources</h3>
              <div className="space-y-4">
                {featuredResources.map((resource) => (
                  <div key={resource.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-gray-900 text-sm">{resource.title}</h4>
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {resource.type}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{resource.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{resource.downloads} downloads</span>
                      <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        Download
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Industry Insights */}
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-4">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                <h3 className="text-lg font-semibold text-gray-900">Industry Insights</h3>
              </div>
              <div className="space-y-3">
                <div className="bg-white rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 text-sm mb-1">AI Adoption Rate</h4>
                  <p className="text-2xl font-bold text-blue-600">78%</p>
                  <p className="text-xs text-gray-600">of businesses using AI for accounting</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 text-sm mb-1">Time Savings</h4>
                  <p className="text-2xl font-bold text-green-600">65%</p>
                  <p className="text-xs text-gray-600">reduction in manual bookkeeping</p>
                </div>
                <div className="bg-white rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 text-sm mb-1">Accuracy Improvement</h4>
                  <p className="text-2xl font-bold text-purple-600">94%</p>
                  <p className="text-xs text-gray-600">fewer errors with AI assistance</p>
                </div>
              </div>
            </div>

            {/* Newsletter Signup */}
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg p-6 text-white">
              <h3 className="text-lg font-semibold mb-2">Stay Updated</h3>
              <p className="text-sm mb-4 opacity-90">Get the latest insights and tips delivered to your inbox.</p>
              <div className="space-y-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-3 py-2 rounded-lg text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
                />
                <button className="w-full bg-white text-blue-600 py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceCenter;

