import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { 
  BookOpen, 
  Search, 
  Filter, 
  Download, 
  Plus,
  TrendingUp,
  TrendingDown
} from 'lucide-react'

const Ledger = () => {
  const ledgerEntries = [
    {
      id: 1,
      account: 'Cash',
      date: '2025-01-10',
      description: 'Client payment received',
      debit: 5000.00,
      credit: 0,
      balance: 15000.00
    },
    {
      id: 2,
      account: 'Office Expenses',
      date: '2025-01-09',
      description: 'Office supplies purchase',
      debit: 234.50,
      credit: 0,
      balance: 1234.50
    },
    {
      id: 3,
      account: 'Accounts Payable',
      date: '2025-01-08',
      description: 'Vendor invoice',
      debit: 0,
      credit: 1500.00,
      balance: 3500.00
    },
    {
      id: 4,
      account: 'Revenue',
      date: '2025-01-07',
      description: 'Service revenue',
      debit: 0,
      credit: 2500.00,
      balance: 45000.00
    },
    {
      id: 5,
      account: 'Software Expenses',
      date: '2025-01-06',
      description: 'Adobe subscription',
      debit: 52.99,
      credit: 0,
      balance: 299.99
    }
  ]

  const accountSummary = [
    { account: 'Cash', balance: 15000.00, type: 'asset' },
    { account: 'Accounts Receivable', balance: 8500.00, type: 'asset' },
    { account: 'Office Equipment', balance: 12000.00, type: 'asset' },
    { account: 'Accounts Payable', balance: 3500.00, type: 'liability' },
    { account: 'Revenue', balance: 45000.00, type: 'revenue' },
    { account: 'Office Expenses', balance: 1234.50, type: 'expense' },
    { account: 'Software Expenses', balance: 299.99, type: 'expense' }
  ]

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">General Ledger</h1>
            <p className="text-gray-600 mt-1">
              View and manage all your account transactions
            </p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Entry
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-4">
              <div className="flex-1 min-w-64">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search transactions..."
                    className="pl-10"
                  />
                </div>
              </div>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Account Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BookOpen className="h-5 w-5" />
                <span>Account Summary</span>
              </CardTitle>
              <CardDescription>
                Current balances by account
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {accountSummary.map((account, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <div className="font-medium text-gray-900">{account.account}</div>
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${
                          account.type === 'asset' ? 'bg-blue-100 text-blue-800' :
                          account.type === 'liability' ? 'bg-red-100 text-red-800' :
                          account.type === 'revenue' ? 'bg-green-100 text-green-800' :
                          'bg-orange-100 text-orange-800'
                        }`}
                      >
                        {account.type}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-gray-900">
                        ${account.balance.toLocaleString()}
                      </div>
                      {account.type === 'revenue' && (
                        <TrendingUp className="h-4 w-4 text-green-500 ml-auto" />
                      )}
                      {account.type === 'expense' && (
                        <TrendingDown className="h-4 w-4 text-red-500 ml-auto" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Ledger Entries */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Ledger Entries</CardTitle>
                <CardDescription>
                  All account transactions and balances
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-2 font-medium text-gray-600">Date</th>
                        <th className="text-left py-3 px-2 font-medium text-gray-600">Account</th>
                        <th className="text-left py-3 px-2 font-medium text-gray-600">Description</th>
                        <th className="text-right py-3 px-2 font-medium text-gray-600">Debit</th>
                        <th className="text-right py-3 px-2 font-medium text-gray-600">Credit</th>
                        <th className="text-right py-3 px-2 font-medium text-gray-600">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ledgerEntries.map((entry) => (
                        <tr key={entry.id} className="border-b hover:bg-gray-50">
                          <td className="py-3 px-2 text-sm text-gray-600">{entry.date}</td>
                          <td className="py-3 px-2 font-medium text-gray-900">{entry.account}</td>
                          <td className="py-3 px-2 text-sm text-gray-600">{entry.description}</td>
                          <td className="py-3 px-2 text-right text-sm">
                            {entry.debit > 0 ? `$${entry.debit.toFixed(2)}` : '-'}
                          </td>
                          <td className="py-3 px-2 text-right text-sm">
                            {entry.credit > 0 ? `$${entry.credit.toFixed(2)}` : '-'}
                          </td>
                          <td className="py-3 px-2 text-right font-medium text-gray-900">
                            ${entry.balance.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Ledger

