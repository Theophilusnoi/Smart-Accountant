import React, { useState, useContext } from 'react';
import { Upload, Download, MessageSquare, FileText, Calendar, Bell, Search, Filter } from 'lucide-react';
import { IndustryContext } from '../contexts/IndustryContext';

const ClientPortal = () => {
  const { selectedIndustry } = useContext(IndustryContext);
  const [activeTab, setActiveTab] = useState('documents');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  // Mock data for demonstration
  const documents = [
    {
      id: 1,
      name: 'Tax Return 2024.pdf',
      type: 'Tax Document',
      size: '2.4 MB',
      uploadDate: '2024-01-15',
      status: 'Processed',
      category: 'tax'
    },
    {
      id: 2,
      name: 'Financial Statement Q4.xlsx',
      type: 'Financial Report',
      size: '1.8 MB',
      uploadDate: '2024-01-10',
      status: 'Under Review',
      category: 'financial'
    },
    {
      id: 3,
      name: 'Invoice Template.docx',
      type: 'Template',
      size: '0.5 MB',
      uploadDate: '2024-01-08',
      status: 'Ready',
      category: 'template'
    }
  ];

  const messages = [
    {
      id: 1,
      from: 'Sarah Johnson (Accountant)',
      subject: 'Q4 Financial Review Complete',
      preview: 'Your Q4 financial statements have been reviewed and are ready for your approval...',
      date: '2024-01-15',
      unread: true
    },
    {
      id: 2,
      from: 'AI Accountant System',
      subject: 'Tax Deadline Reminder',
      preview: 'Reminder: Your tax filing deadline is approaching in 30 days...',
      date: '2024-01-14',
      unread: false
    },
    {
      id: 3,
      from: 'Michael Chen (Tax Specialist)',
      subject: 'Additional Documentation Needed',
      preview: 'We need a few additional documents to complete your tax preparation...',
      date: '2024-01-12',
      unread: false
    }
  ];

  const appointments = [
    {
      id: 1,
      title: 'Tax Planning Consultation',
      date: '2024-01-20',
      time: '2:00 PM',
      type: 'Video Call',
      status: 'Confirmed'
    },
    {
      id: 2,
      title: 'Financial Review Meeting',
      date: '2024-01-25',
      time: '10:00 AM',
      type: 'In-Person',
      status: 'Pending'
    }
  ];

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || doc.category === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'Processed': return 'text-green-600 bg-green-100';
      case 'Under Review': return 'text-yellow-600 bg-yellow-100';
      case 'Ready': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Client Portal</h1>
              <p className="text-gray-600 mt-2">Secure document sharing and communication hub</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Bell className="h-4 w-4" />
                <span>3 new notifications</span>
              </div>
              <div className="h-8 w-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                JD
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-white rounded-lg shadow-sm mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'documents', label: 'Documents', icon: FileText },
                { id: 'messages', label: 'Messages', icon: MessageSquare },
                { id: 'appointments', label: 'Appointments', icon: Calendar }
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Documents Tab */}
        {activeTab === 'documents' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Document Management</h2>
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-700 flex items-center space-x-2">
                <Upload className="h-4 w-4" />
                <span>Upload Document</span>
              </button>
            </div>

            {/* Search and Filter */}
            <div className="flex items-center space-x-4 mb-6">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search documents..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-400" />
                <select
                  value={selectedFilter}
                  onChange={(e) => setSelectedFilter(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Categories</option>
                  <option value="tax">Tax Documents</option>
                  <option value="financial">Financial Reports</option>
                  <option value="template">Templates</option>
                </select>
              </div>
            </div>

            {/* Documents List */}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Document
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Type
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Size
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Upload Date
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredDocuments.map((doc) => (
                    <tr key={doc.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-3" />
                          <div>
                            <div className="text-sm font-medium text-gray-900">{doc.name}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {doc.type}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {doc.size}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {doc.uploadDate}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(doc.status)}`}>
                          {doc.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <button className="text-blue-600 hover:text-blue-900 mr-4">
                          <Download className="h-4 w-4" />
                        </button>
                        <button className="text-gray-600 hover:text-gray-900">
                          <MessageSquare className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Messages Tab */}
        {activeTab === 'messages' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Messages</h2>
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-700">
                New Message
              </button>
            </div>

            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`p-4 border rounded-lg hover:bg-gray-50 cursor-pointer ${message.unread ? 'bg-blue-50 border-blue-200' : 'border-gray-200'}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className={`font-medium ${message.unread ? 'text-blue-900' : 'text-gray-900'}`}>
                          {message.from}
                        </h3>
                        {message.unread && (
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            New
                          </span>
                        )}
                      </div>
                      <h4 className={`text-sm font-medium mb-2 ${message.unread ? 'text-blue-800' : 'text-gray-800'}`}>
                        {message.subject}
                      </h4>
                      <p className="text-sm text-gray-600">{message.preview}</p>
                    </div>
                    <div className="text-sm text-gray-500 ml-4">
                      {message.date}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Appointments Tab */}
        {activeTab === 'appointments' && (
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Appointments</h2>
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-700">
                Schedule Appointment
              </button>
            </div>

            <div className="space-y-4">
              {appointments.map((appointment) => (
                <div key={appointment.id} className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">{appointment.title}</h3>
                      <div className="flex items-center space-x-4 mt-2 text-sm text-gray-600">
                        <span>{appointment.date}</span>
                        <span>{appointment.time}</span>
                        <span>{appointment.type}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        appointment.status === 'Confirmed' 
                          ? 'text-green-600 bg-green-100' 
                          : 'text-yellow-600 bg-yellow-100'
                      }`}>
                        {appointment.status}
                      </span>
                      <button className="text-blue-600 hover:text-blue-900 text-sm font-medium">
                        Join Meeting
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ClientPortal;

