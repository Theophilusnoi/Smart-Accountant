import React, { useState, useContext } from 'react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, Users, FileText, Download, Calendar, Filter } from 'lucide-react';
import { IndustryContext } from '../contexts/IndustryContext';

const Analytics = () => {
  const { selectedIndustry } = useContext(IndustryContext);
  const [selectedPeriod, setSelectedPeriod] = useState('30days');
  const [selectedMetric, setSelectedMetric] = useState('revenue');

  // Mock data for demonstration
  const revenueData = [
    { month: 'Jan', revenue: 45000, expenses: 32000, profit: 13000 },
    { month: 'Feb', revenue: 52000, expenses: 35000, profit: 17000 },
    { month: 'Mar', revenue: 48000, expenses: 33000, profit: 15000 },
    { month: 'Apr', revenue: 61000, expenses: 38000, profit: 23000 },
    { month: 'May', revenue: 55000, expenses: 36000, profit: 19000 },
    { month: 'Jun', revenue: 67000, expenses: 41000, profit: 26000 }
  ];

  const expenseBreakdown = [
    { name: 'Salaries', value: 35, amount: 14000 },
    { name: 'Rent', value: 20, amount: 8000 },
    { name: 'Utilities', value: 15, amount: 6000 },
    { name: 'Marketing', value: 12, amount: 4800 },
    { name: 'Supplies', value: 10, amount: 4000 },
    { name: 'Other', value: 8, amount: 3200 }
  ];

  const clientGrowth = [
    { month: 'Jan', clients: 45, newClients: 8, churnedClients: 2 },
    { month: 'Feb', clients: 51, newClients: 9, churnedClients: 3 },
    { month: 'Mar', clients: 58, newClients: 10, churnedClients: 3 },
    { month: 'Apr', clients: 65, newClients: 12, churnedClients: 5 },
    { month: 'May', clients: 72, newClients: 11, churnedClients: 4 },
    { month: 'Jun', clients: 79, newClients: 13, churnedClients: 6 }
  ];

  const industryBenchmarks = {
    'Hospitality & Hotels': {
      occupancyRate: 87.5,
      averageDailyRate: 245,
      revPAR: 214,
      guestSatisfaction: 4.8
    },
    'Construction & Contracting': {
      projectMargin: 15.2,
      equipmentUtilization: 78,
      safetyScore: 94,
      onTimeCompletion: 89
    },
    'Retail & E-commerce': {
      inventoryTurnover: 6.2,
      conversionRate: 3.4,
      customerLifetimeValue: 1250,
      returnRate: 8.5
    }
  };

  const kpiData = [
    {
      title: 'Total Revenue',
      value: '$67,000',
      change: '+12.5%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-green-600'
    },
    {
      title: 'Active Clients',
      value: '79',
      change: '+9.7%',
      trend: 'up',
      icon: Users,
      color: 'text-blue-600'
    },
    {
      title: 'Profit Margin',
      value: '38.8%',
      change: '+2.1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-purple-600'
    },
    {
      title: 'Invoices Processed',
      value: '234',
      change: '-3.2%',
      trend: 'down',
      icon: FileText,
      color: 'text-orange-600'
    }
  ];

  const COLORS = ['#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#6B7280'];

  const periods = [
    { value: '7days', label: 'Last 7 Days' },
    { value: '30days', label: 'Last 30 Days' },
    { value: '90days', label: 'Last 90 Days' },
    { value: '1year', label: 'Last Year' }
  ];

  const metrics = [
    { value: 'revenue', label: 'Revenue Analysis' },
    { value: 'expenses', label: 'Expense Analysis' },
    { value: 'clients', label: 'Client Growth' },
    { value: 'industry', label: 'Industry Benchmarks' }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Performance Analytics</h1>
              <p className="text-gray-600 mt-2">Comprehensive business insights and performance metrics</p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {periods.map((period) => (
                  <option key={period.value} value={period.value}>
                    {period.label}
                  </option>
                ))}
              </select>
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg hover:from-blue-600 hover:to-purple-700 flex items-center space-x-2">
                <Download className="h-4 w-4" />
                <span>Export Report</span>
              </button>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          {kpiData.map((kpi, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{kpi.title}</p>
                  <p className="text-2xl font-bold text-gray-900 mt-2">{kpi.value}</p>
                </div>
                <div className={`p-3 rounded-full bg-gray-100 ${kpi.color}`}>
                  <kpi.icon className="h-6 w-6" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                {kpi.trend === 'up' ? (
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                )}
                <span className={`text-sm font-medium ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                  {kpi.change}
                </span>
                <span className="text-sm text-gray-500 ml-2">vs last period</span>
              </div>
            </div>
          ))}
        </div>

        {/* Metric Selection */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-wrap gap-2">
            {metrics.map((metric) => (
              <button
                key={metric.value}
                onClick={() => setSelectedMetric(metric.value)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedMetric === metric.value
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {metric.label}
              </button>
            ))}
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Revenue Analysis */}
          {selectedMetric === 'revenue' && (
            <>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue vs Expenses</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, '']} />
                    <Legend />
                    <Bar dataKey="revenue" fill="#3B82F6" name="Revenue" />
                    <Bar dataKey="expenses" fill="#EF4444" name="Expenses" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Profit Trend</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Profit']} />
                    <Line type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </>
          )}

          {/* Expense Analysis */}
          {selectedMetric === 'expenses' && (
            <>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Breakdown</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={expenseBreakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {expenseBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value, name) => [`${value}%`, name]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Details</h3>
                <div className="space-y-4">
                  {expenseBreakdown.map((expense, index) => (
                    <div key={expense.name} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div 
                          className="w-4 h-4 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        ></div>
                        <span className="font-medium text-gray-900">{expense.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold text-gray-900">${expense.amount.toLocaleString()}</div>
                        <div className="text-sm text-gray-500">{expense.value}%</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* Client Growth */}
          {selectedMetric === 'clients' && (
            <>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Client Growth</h3>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={clientGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="clients" stroke="#3B82F6" strokeWidth={3} name="Total Clients" />
                    <Line type="monotone" dataKey="newClients" stroke="#10B981" strokeWidth={2} name="New Clients" />
                    <Line type="monotone" dataKey="churnedClients" stroke="#EF4444" strokeWidth={2} name="Churned Clients" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Client Metrics</h3>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Client Retention Rate</span>
                      <span className="text-sm font-semibold text-green-600">92%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Average Client Value</span>
                      <span className="text-sm font-semibold text-blue-600">$2,450</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-500 h-2 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-gray-700">Client Satisfaction</span>
                      <span className="text-sm font-semibold text-purple-600">4.7/5</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-500 h-2 rounded-full" style={{ width: '94%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Industry Benchmarks */}
          {selectedMetric === 'industry' && selectedIndustry && (
            <>
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  {selectedIndustry} Benchmarks
                </h3>
                <div className="space-y-4">
                  {industryBenchmarks[selectedIndustry] && Object.entries(industryBenchmarks[selectedIndustry]).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium text-gray-700 capitalize">
                        {key.replace(/([A-Z])/g, ' $1').trim()}
                      </span>
                      <span className="font-semibold text-blue-600">
                        {typeof value === 'number' ? (
                          key.includes('Rate') || key.includes('Score') || key.includes('Completion') 
                            ? `${value}%` 
                            : key.includes('Daily') || key.includes('PAR') || key.includes('Value')
                            ? `$${value}`
                            : value
                        ) : value}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance vs Industry</h3>
                <div className="space-y-4">
                  <div className="p-4 border-l-4 border-green-500 bg-green-50">
                    <h4 className="font-medium text-green-800">Above Average</h4>
                    <p className="text-sm text-green-700">Your performance is 15% above industry average</p>
                  </div>
                  <div className="p-4 border-l-4 border-blue-500 bg-blue-50">
                    <h4 className="font-medium text-blue-800">Industry Leader</h4>
                    <p className="text-sm text-blue-700">Top 10% in customer satisfaction metrics</p>
                  </div>
                  <div className="p-4 border-l-4 border-yellow-500 bg-yellow-50">
                    <h4 className="font-medium text-yellow-800">Improvement Opportunity</h4>
                    <p className="text-sm text-yellow-700">Cost optimization could improve margins by 8%</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Insights and Recommendations */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">AI-Powered Insights</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="font-medium text-blue-900 mb-2">Revenue Opportunity</h4>
              <p className="text-sm text-blue-800">
                Your revenue growth is accelerating. Consider expanding services to capture 23% more market share.
              </p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg border border-green-200">
              <h4 className="font-medium text-green-900 mb-2">Cost Optimization</h4>
              <p className="text-sm text-green-800">
                Utility costs are 12% above average. Implementing energy-efficient solutions could save $2,400 annually.
              </p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h4 className="font-medium text-purple-900 mb-2">Client Retention</h4>
              <p className="text-sm text-purple-800">
                Client satisfaction is high. Focus on upselling premium services to increase average client value.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;

