import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useIndustry } from '../contexts/IndustryContext';
import { useAuth } from '../hooks/useAuth';
import IndustrySelector from '../components/IndustrySelector';
import { CheckCircle, ArrowRight, Settings, BarChart3, Shield, Zap } from 'lucide-react';

const IndustryOnboarding = () => {
  const navigate = useNavigate();
  const { selectIndustry, selectedIndustry, industryConfig, isLoading } = useIndustry();
  const { user } = useAuth();
  const [step, setStep] = useState(1);
  const [setupProgress, setSetupProgress] = useState(0);

  const handleIndustrySelect = async (industryId) => {
    await selectIndustry(industryId);
    if (industryId) {
      setStep(2);
      simulateSetup();
    }
  };

  const simulateSetup = () => {
    let progress = 0;
    const interval = setInterval(() => {
      progress += 20;
      setSetupProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => setStep(3), 500);
      }
    }, 300);
  };

  const completeOnboarding = () => {
    navigate('/dashboard');
  };

  const benefits = [
    {
      icon: Settings,
      title: 'Industry-Specific Features',
      description: 'Get tools and workflows designed specifically for your industry'
    },
    {
      icon: BarChart3,
      title: 'Specialized Reports',
      description: 'Access reports and analytics that matter to your business'
    },
    {
      icon: Shield,
      title: 'Compliance Ready',
      description: 'Built-in compliance features for your industry regulations'
    },
    {
      icon: Zap,
      title: 'Smart Automation',
      description: 'AI-powered automation tailored to your industry workflows'
    }
  ];

  if (step === 1) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4 py-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">AI</span>
              </div>
              <span className="ml-3 text-2xl font-bold text-gray-900">Accountant</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Welcome to AI Accountant
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Let's customize your accounting platform for your specific industry. 
              This ensures you get the most relevant features and workflows for your business.
            </p>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <div key={index} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{benefit.title}</h3>
                  <p className="text-sm text-gray-600">{benefit.description}</p>
                </div>
              );
            })}
          </div>

          {/* Industry Selection */}
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <IndustrySelector 
              onIndustrySelect={handleIndustrySelect}
              selectedIndustry={selectedIndustry}
            />
          </div>

          {/* Progress Indicator */}
          <div className="flex justify-center mt-8">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                  1
                </div>
                <span className="ml-2 text-sm font-medium text-blue-600">Select Industry</span>
              </div>
              <div className="w-8 h-px bg-gray-300"></div>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-gray-500 text-sm font-medium">
                  2
                </div>
                <span className="ml-2 text-sm text-gray-500">Setup Platform</span>
              </div>
              <div className="w-8 h-px bg-gray-300"></div>
              <div className="flex items-center">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-gray-500 text-sm font-medium">
                  3
                </div>
                <span className="ml-2 text-sm text-gray-500">Get Started</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Settings className="w-8 h-8 text-white animate-spin" />
            </div>
            
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Setting Up Your Platform
            </h2>
            
            <p className="text-gray-600 mb-6">
              We're customizing AI Accountant for the {industryConfig?.name} industry. 
              This will only take a moment.
            </p>

            {/* Progress Bar */}
            <div className="w-full bg-gray-200 rounded-full h-3 mb-6">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${setupProgress}%` }}
              ></div>
            </div>

            <div className="text-sm text-gray-500">
              {setupProgress < 20 && "Configuring industry-specific features..."}
              {setupProgress >= 20 && setupProgress < 40 && "Setting up chart of accounts..."}
              {setupProgress >= 40 && setupProgress < 60 && "Preparing dashboard widgets..."}
              {setupProgress >= 60 && setupProgress < 80 && "Configuring reports and analytics..."}
              {setupProgress >= 80 && setupProgress < 100 && "Finalizing setup..."}
              {setupProgress >= 100 && "Setup complete!"}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (step === 3) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              You're All Set!
            </h2>
            
            <p className="text-lg text-gray-600 mb-8">
              Your AI Accountant platform has been customized for the {industryConfig?.name} industry. 
              You now have access to specialized features and workflows.
            </p>

            {/* Feature Summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">Dashboard Widgets</h3>
                <p className="text-sm text-blue-700">
                  {industryConfig?.dashboardWidgets?.length || 0} specialized widgets
                </p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="font-semibold text-purple-900 mb-2">Industry Reports</h3>
                <p className="text-sm text-purple-700">
                  {industryConfig?.reports?.length || 0} specialized reports
                </p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">Workflows</h3>
                <p className="text-sm text-green-700">
                  {industryConfig?.workflows?.length || 0} automated workflows
                </p>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg">
                <h3 className="font-semibold text-orange-900 mb-2">Integrations</h3>
                <p className="text-sm text-orange-700">
                  {industryConfig?.integrations?.length || 0} industry integrations
                </p>
              </div>
            </div>

            <button
              onClick={completeOnboarding}
              className="inline-flex items-center px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-lg hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Go to Dashboard
              <ArrowRight className="ml-2 w-5 h-5" />
            </button>

            <p className="text-sm text-gray-500 mt-4">
              You can always change your industry settings later in your account preferences.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return null;
};

export default IndustryOnboarding;

