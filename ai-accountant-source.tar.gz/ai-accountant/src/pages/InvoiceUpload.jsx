import { useState } from 'react'
import PageHeader from '../components/PageHeader'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Loader2,
  Eye,
  Download,
  Trash2
} from 'lucide-react'
import { useInvoice } from '../hooks/useInvoice.jsx'

const InvoiceUpload = () => {
  const { invoices, loading, uploadInvoice } = useInvoice()
  const [dragActive, setDragActive] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)
  const [extractedData, setExtractedData] = useState(null)

  // Mock AI data extraction (would use OpenAI API in production)
  const extractInvoiceData = async (file) => {
    // Simulate AI processing time
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    // Mock extracted data
    return {
      vendor: 'ABC Office Supplies',
      amount: 234.50,
      date: '2025-01-10',
      invoiceNumber: 'INV-2025-001',
      description: 'Office supplies and stationery',
      category: 'Office Expenses',
      confidence: 0.95
    }
  }

  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0])
    }
  }

  const handleFileUpload = async (file) => {
    if (!file) return

    setIsProcessing(true)
    setUploadProgress(0)

    // Simulate upload progress
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 10
      })
    }, 200)

    try {
      // Extract data using AI
      const extractedData = await extractInvoiceData(file)
      setExtractedData(extractedData)
      setUploadProgress(100)
      
      // Upload to backend
      await uploadInvoice(file, extractedData)
    } catch (error) {
      console.error('Upload failed:', error)
    } finally {
      setIsProcessing(false)
      clearInterval(progressInterval)
    }
  }

  const handleFileSelect = (e) => {
    if (e.target.files && e.target.files[0]) {
      handleFileUpload(e.target.files[0])
    }
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <PageHeader 
        title="Upload Invoice"
        subtitle="Upload and process invoices with AI-powered data extraction"
        backTo="/dashboard"
      />

      {/* Upload Area */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>AI-Powered Invoice Processing</CardTitle>
          <CardDescription>
            Upload PDF or image files. Our AI will automatically extract key information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive 
                ? 'border-blue-500 bg-blue-50' 
                : 'border-gray-300 hover:border-gray-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-lg font-medium text-gray-900 mb-2">
              Drop files here or click to upload
            </p>
            <p className="text-sm text-gray-500 mb-4">
              Supports PDF, JPG, PNG files up to 10MB
            </p>
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileSelect}
              className="hidden"
              id="file-upload"
            />
            <Button asChild>
              <label htmlFor="file-upload" className="cursor-pointer">
                <FileText className="h-4 w-4 mr-2" />
                Choose File
              </label>
            </Button>
          </div>

          {/* Upload Progress */}
          {isProcessing && (
            <div className="mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Processing...</span>
                <span className="text-sm text-gray-500">{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="mb-2" />
              <p className="text-xs text-gray-500">
                AI is extracting data from your invoice...
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Extracted Data Review */}
      {extractedData && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center">
              <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
              Data Extracted Successfully
            </CardTitle>
            <CardDescription>
              Review and edit the extracted information before saving
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="vendor">Vendor</Label>
                <Input 
                  id="vendor" 
                  defaultValue={extractedData.vendor}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="amount">Amount</Label>
                <Input 
                  id="amount" 
                  type="number" 
                  defaultValue={extractedData.amount}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="date">Date</Label>
                <Input 
                  id="date" 
                  type="date" 
                  defaultValue={extractedData.date}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="invoice-number">Invoice Number</Label>
                <Input 
                  id="invoice-number" 
                  defaultValue={extractedData.invoiceNumber}
                  className="mt-1"
                />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="description">Description</Label>
                <Input 
                  id="description" 
                  defaultValue={extractedData.description}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="category">Category</Label>
                <Input 
                  id="category" 
                  defaultValue={extractedData.category}
                  className="mt-1"
                />
              </div>
              <div className="flex items-center">
                <Badge variant="outline" className="text-green-600">
                  {Math.round(extractedData.confidence * 100)}% Confidence
                </Badge>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 mt-6">
              <Button variant="outline">
                <Eye className="h-4 w-4 mr-2" />
                Preview
              </Button>
              <Button>
                <CheckCircle className="h-4 w-4 mr-2" />
                Save Invoice
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Uploads */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Uploads</CardTitle>
          <CardDescription>
            Your recently processed invoices
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin mr-2" />
              Loading...
            </div>
          ) : (
            <div className="space-y-3">
              {invoices.slice(0, 5).map((invoice) => (
                <div key={invoice.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-gray-400" />
                    <div>
                      <p className="font-medium">{invoice.vendor}</p>
                      <p className="text-sm text-gray-500">
                        ${invoice.amount} • {invoice.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant={invoice.status === 'processed' ? 'default' : 'secondary'}
                    >
                      {invoice.status}
                    </Badge>
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default InvoiceUpload

