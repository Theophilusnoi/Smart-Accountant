import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  BarChart3, 
  Download, 
  TrendingUp, 
  TrendingDown,
  DollarSign,
  PieChart,
  Calendar
} from 'lucide-react'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart
} from 'recharts'

const FinancialReports = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('monthly')

  // Mock financial data
  const monthlyData = [
    { month: 'Jan', revenue: 45000, expenses: 12000, profit: 33000 },
    { month: 'Feb', revenue: 52000, expenses: 14000, profit: 38000 },
    { month: 'Mar', revenue: 48000, expenses: 13000, profit: 35000 },
    { month: 'Apr', revenue: 61000, expenses: 15000, profit: 46000 },
    { month: 'May', revenue: 55000, expenses: 14500, profit: 40500 },
    { month: 'Jun', revenue: 67000, expenses: 16000, profit: 51000 }
  ]

  const expenseBreakdown = [
    { name: 'Office Expenses', value: 4500, color: '#8884d8' },
    { name: 'Software', value: 2800, color: '#82ca9d' },
    { name: 'Marketing', value: 3200, color: '#ffc658' },
    { name: 'Travel', value: 1500, color: '#ff7300' },
    { name: 'Utilities', value: 800, color: '#00ff88' }
  ]

  const cashFlowData = [
    { month: 'Jan', inflow: 45000, outflow: 12000, net: 33000 },
    { month: 'Feb', inflow: 52000, outflow: 14000, net: 38000 },
    { month: 'Mar', inflow: 48000, outflow: 13000, net: 35000 },
    { month: 'Apr', inflow: 61000, outflow: 15000, net: 46000 },
    { month: 'May', inflow: 55000, outflow: 14500, net: 40500 },
    { month: 'Jun', inflow: 67000, outflow: 16000, net: 51000 }
  ]

  const balanceSheetData = {
    assets: {
      current: {
        cash: 25000,
        accountsReceivable: 15000,
        inventory: 8000
      },
      fixed: {
        equipment: 45000,
        property: 120000
      }
    },
    liabilities: {
      current: {
        accountsPayable: 8000,
        shortTermDebt: 5000
      },
      longTerm: {
        longTermDebt: 35000
      }
    },
    equity: {
      retainedEarnings: 165000
    }
  }

  const totalAssets = Object.values(balanceSheetData.assets.current).reduce((a, b) => a + b, 0) +
                     Object.values(balanceSheetData.assets.fixed).reduce((a, b) => a + b, 0)
  
  const totalLiabilities = Object.values(balanceSheetData.liabilities.current).reduce((a, b) => a + b, 0) +
                          Object.values(balanceSheetData.liabilities.longTerm).reduce((a, b) => a + b, 0)

  const exportReport = (type) => {
    // Mock export functionality
    alert(`Exporting ${type} report...`)
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Financial Reports</h1>
            <p className="text-gray-600 mt-1">Comprehensive financial statements and analysis</p>
          </div>
          <div className="flex space-x-2">
            <Button variant="outline" onClick={() => exportReport('PDF')}>
              <Download className="h-4 w-4 mr-2" />
              Export PDF
            </Button>
            <Button variant="outline" onClick={() => exportReport('Excel')}>
              <Download className="h-4 w-4 mr-2" />
              Export Excel
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">$328K</div>
                  <div className="text-sm text-gray-600">Total Revenue</div>
                  <div className="flex items-center text-green-600 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    +12.5%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <TrendingDown className="h-8 w-8 text-red-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">$84K</div>
                  <div className="text-sm text-gray-600">Total Expenses</div>
                  <div className="flex items-center text-red-600 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    +3.2%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-8 w-8 text-blue-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">$244K</div>
                  <div className="text-sm text-gray-600">Net Profit</div>
                  <div className="flex items-center text-green-600 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    +18.7%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center space-x-2">
                <PieChart className="h-8 w-8 text-purple-600" />
                <div>
                  <div className="text-2xl font-bold text-gray-900">74.4%</div>
                  <div className="text-sm text-gray-600">Profit Margin</div>
                  <div className="flex items-center text-green-600 text-sm">
                    <TrendingUp className="h-4 w-4 mr-1" />
                    +2.1%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Reports Tabs */}
        <Tabs defaultValue="profit-loss" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profit-loss">Profit & Loss</TabsTrigger>
            <TabsTrigger value="balance-sheet">Balance Sheet</TabsTrigger>
            <TabsTrigger value="cash-flow">Cash Flow</TabsTrigger>
            <TabsTrigger value="expenses">Expense Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="profit-loss">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue vs Expenses</CardTitle>
                  <CardDescription>Monthly comparison over the last 6 months</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, '']} />
                      <Bar dataKey="revenue" fill="#3b82f6" name="Revenue" />
                      <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Profit Trend</CardTitle>
                  <CardDescription>Net profit over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Profit']} />
                      <Area type="monotone" dataKey="profit" stroke="#10b981" fill="#10b981" fillOpacity={0.3} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Profit & Loss Statement</CardTitle>
                <CardDescription>For the period ending June 30, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="font-medium">Total Revenue</span>
                    <span className="font-bold text-green-600">$328,000.00</span>
                  </div>
                  <div className="space-y-2 pl-4">
                    <div className="flex justify-between">
                      <span>Service Revenue</span>
                      <span>$280,000.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Product Sales</span>
                      <span>$48,000.00</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <span className="font-medium">Total Expenses</span>
                    <span className="font-bold text-red-600">$84,500.00</span>
                  </div>
                  <div className="space-y-2 pl-4">
                    <div className="flex justify-between">
                      <span>Office Expenses</span>
                      <span>$27,000.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Software & Technology</span>
                      <span>$16,800.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Marketing</span>
                      <span>$19,200.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Travel & Entertainment</span>
                      <span>$9,000.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Utilities</span>
                      <span>$4,800.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Other Expenses</span>
                      <span>$7,700.00</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border-t-2">
                    <span className="font-bold">Net Profit</span>
                    <span className="font-bold text-blue-600">$243,500.00</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="balance-sheet">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Assets</CardTitle>
                  <CardDescription>Current and fixed assets breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Current Assets</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Cash & Cash Equivalents</span>
                          <span>${balanceSheetData.assets.current.cash.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Accounts Receivable</span>
                          <span>${balanceSheetData.assets.current.accountsReceivable.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Inventory</span>
                          <span>${balanceSheetData.assets.current.inventory.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Total Current Assets</span>
                          <span>${Object.values(balanceSheetData.assets.current).reduce((a, b) => a + b, 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Fixed Assets</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Equipment</span>
                          <span>${balanceSheetData.assets.fixed.equipment.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Property</span>
                          <span>${balanceSheetData.assets.fixed.property.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Total Fixed Assets</span>
                          <span>${Object.values(balanceSheetData.assets.fixed).reduce((a, b) => a + b, 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between font-bold text-lg border-t-2 pt-2">
                      <span>Total Assets</span>
                      <span>${totalAssets.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Liabilities & Equity</CardTitle>
                  <CardDescription>Current liabilities, long-term debt, and equity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Current Liabilities</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Accounts Payable</span>
                          <span>${balanceSheetData.liabilities.current.accountsPayable.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Short-term Debt</span>
                          <span>${balanceSheetData.liabilities.current.shortTermDebt.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Total Current Liabilities</span>
                          <span>${Object.values(balanceSheetData.liabilities.current).reduce((a, b) => a + b, 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Long-term Liabilities</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Long-term Debt</span>
                          <span>${balanceSheetData.liabilities.longTerm.longTermDebt.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Total Long-term Liabilities</span>
                          <span>${Object.values(balanceSheetData.liabilities.longTerm).reduce((a, b) => a + b, 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">Equity</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Retained Earnings</span>
                          <span>${balanceSheetData.equity.retainedEarnings.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-medium border-t pt-2">
                          <span>Total Equity</span>
                          <span>${Object.values(balanceSheetData.equity).reduce((a, b) => a + b, 0).toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between font-bold text-lg border-t-2 pt-2">
                      <span>Total Liabilities & Equity</span>
                      <span>${(totalLiabilities + Object.values(balanceSheetData.equity).reduce((a, b) => a + b, 0)).toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="cash-flow">
            <Card>
              <CardHeader>
                <CardTitle>Cash Flow Analysis</CardTitle>
                <CardDescription>Monthly cash inflows and outflows</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <LineChart data={cashFlowData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, '']} />
                    <Line type="monotone" dataKey="inflow" stroke="#10b981" strokeWidth={2} name="Cash Inflow" />
                    <Line type="monotone" dataKey="outflow" stroke="#ef4444" strokeWidth={2} name="Cash Outflow" />
                    <Line type="monotone" dataKey="net" stroke="#3b82f6" strokeWidth={3} name="Net Cash Flow" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="expenses">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Expense Breakdown</CardTitle>
                  <CardDescription>Distribution of expenses by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <RechartsPieChart>
                      <Pie
                        data={expenseBreakdown}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {expenseBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`$${value.toLocaleString()}`, 'Amount']} />
                    </RechartsPieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Expense Details</CardTitle>
                  <CardDescription>Detailed breakdown by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {expenseBreakdown.map((expense, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div 
                            className="w-4 h-4 rounded-full" 
                            style={{ backgroundColor: expense.color }}
                          ></div>
                          <span className="font-medium">{expense.name}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">${expense.value.toLocaleString()}</div>
                          <div className="text-sm text-gray-600">
                            {((expense.value / expenseBreakdown.reduce((sum, e) => sum + e.value, 0)) * 100).toFixed(1)}%
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default FinancialReports

