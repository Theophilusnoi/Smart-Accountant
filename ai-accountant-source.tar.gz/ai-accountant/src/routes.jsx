import { createBrowserRouter } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Dashboard from './pages/Dashboard'
import IndustryOnboarding from './pages/IndustryOnboarding'
import Invoices from './pages/Invoices'
import ClientPortal from './pages/ClientPortal'
import ResourceCenter from './pages/ResourceCenter'
import Analytics from './pages/Analytics'
import InvoiceUpload from './pages/InvoiceUpload'
import Ledger from './pages/Ledger'
import JournalEntries from './pages/JournalEntries'
import TrialBalance from './pages/TrialBalance'
import FinancialReports from './pages/FinancialReports'
import CostOptimization from './pages/CostOptimization'
import Subscription from './pages/Subscription'
import Settings from './pages/Settings'
import Login from './pages/Login'
import ProtectedRoute from './components/ProtectedRoute'

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout />,
    children: [
      {
        index: true,
        element: <Home />
      },
      {
        path: 'login',
        element: <Login />
      },
      {
        path: 'onboarding',
        element: (
          <ProtectedRoute>
            <IndustryOnboarding />
          </ProtectedRoute>
        )
      },
      {
        path: 'dashboard',
        element: (
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        )
      },
      {
        path: 'invoices',
        element: (
          <ProtectedRoute>
            <Invoices />
          </ProtectedRoute>
        )
      },
      {
        path: 'client-portal',
        element: (
          <ProtectedRoute>
            <ClientPortal />
          </ProtectedRoute>
        )
      },
      {
        path: 'resources',
        element: (
          <ProtectedRoute>
            <ResourceCenter />
          </ProtectedRoute>
        )
      },
      {
        path: 'analytics',
        element: (
          <ProtectedRoute>
            <Analytics />
          </ProtectedRoute>
        )
      },
      {
        path: 'invoice-upload',
        element: (
          <ProtectedRoute>
            <InvoiceUpload />
          </ProtectedRoute>
        )
      },
      {
        path: 'ledger',
        element: (
          <ProtectedRoute>
            <Ledger />
          </ProtectedRoute>
        )
      },
      {
        path: 'journal-entries',
        element: (
          <ProtectedRoute>
            <JournalEntries />
          </ProtectedRoute>
        )
      },
      {
        path: 'trial-balance',
        element: (
          <ProtectedRoute>
            <TrialBalance />
          </ProtectedRoute>
        )
      },
      {
        path: 'financial-reports',
        element: (
          <ProtectedRoute>
            <FinancialReports />
          </ProtectedRoute>
        )
      },
      {
        path: 'cost-optimization',
        element: (
          <ProtectedRoute>
            <CostOptimization />
          </ProtectedRoute>
        )
      },
      {
        path: 'subscription',
        element: (
          <ProtectedRoute>
            <Subscription />
          </ProtectedRoute>
        )
      },
      {
        path: 'settings',
        element: (
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        )
      }
    ]
  }
])

export default router

