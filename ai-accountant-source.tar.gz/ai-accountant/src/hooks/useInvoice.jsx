import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase.js'
import { useAuth } from './useAuth.jsx'

export const useInvoice = () => {
  const { user } = useAuth()
  const [invoices, setInvoices] = useState([])
  const [loading, setLoading] = useState(false)

  // N8N webhook URL (would be from environment variables)
  const N8N_WEBHOOK_URL = import.meta.env.VITE_N8N_WEBHOOK || 'https://your-n8n-domain.com/webhook/invoice-upload'

  const uploadInvoice = async (file, extractedData) => {
    setLoading(true)
    try {
      // Upload file to Supabase Storage (if configured)
      let fileUrl = null
      try {
        const fileName = `${user?.id}/${Date.now()}-${file.name}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('invoices')
          .upload(fileName, file)
        
        if (!uploadError) {
          const { data: { publicUrl } } = supabase.storage
            .from('invoices')
            .getPublicUrl(fileName)
          fileUrl = publicUrl
        }
      } catch (err) {
        console.warn('File upload failed, continuing without file URL:', err)
      }

      // Save invoice data to database
      const invoiceData = {
        user_id: user?.id,
        vendor: extractedData.vendor,
        date: extractedData.date,
        amount: extractedData.amount,
        tax: extractedData.tax,
        description: extractedData.description,
        category: extractedData.category,
        status: 'processed',
        file_url: fileUrl
      }

      try {
        const { data, error } = await supabase
          .from('invoices')
          .insert([invoiceData])
          .select()

        if (!error && data) {
          setInvoices(prev => [data[0], ...prev])
        }
      } catch (err) {
        console.warn('Database insert failed, using mock data:', err)
        // Mock data for demo
        const mockInvoice = {
          id: Date.now(),
          ...invoiceData,
          created_at: new Date().toISOString()
        }
        setInvoices(prev => [mockInvoice, ...prev])
      }

      // Send to N8N webhook for processing
      try {
        await fetch(N8N_WEBHOOK_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            ...extractedData,
            user_id: user?.id,
            file_url: fileUrl
          })
        })
      } catch (err) {
        console.warn('N8N webhook failed:', err)
      }

      return { success: true, error: null }
    } catch (error) {
      return { success: false, error }
    } finally {
      setLoading(false)
    }
  }

  const fetchInvoices = async () => {
    if (!user) return

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('invoices')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (!error && data) {
        setInvoices(data)
      } else {
        // Mock data for demo
        const mockInvoices = [
          {
            id: 1,
            vendor: 'Acme Corp',
            date: '2025-01-10',
            amount: 1234.56,
            tax: 123.45,
            description: 'Office supplies and equipment',
            category: 'Office Expenses',
            status: 'processed',
            created_at: '2025-01-10T10:00:00Z'
          },
          {
            id: 2,
            vendor: 'Tech Solutions',
            date: '2025-01-09',
            amount: 2500.00,
            tax: 250.00,
            description: 'Software licensing',
            category: 'Software',
            status: 'processed',
            created_at: '2025-01-09T14:30:00Z'
          }
        ]
        setInvoices(mockInvoices)
      }
    } catch (err) {
      console.warn('Failed to fetch invoices:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (user) {
      fetchInvoices()
    }
  }, [user])

  return {
    invoices,
    loading,
    uploadInvoice,
    fetchInvoices
  }
}

