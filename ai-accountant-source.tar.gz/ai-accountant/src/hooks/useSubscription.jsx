import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase.js'
import { useAuth } from './useAuth.jsx'

export const useSubscription = () => {
  const { user } = useAuth()
  const [subscription, setSubscription] = useState(null)
  const [loading, setLoading] = useState(false)

  // Stripe configuration (would be from environment variables)
  const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_...'

  const plans = [
    {
      id: 'free',
      name: 'Free Tier',
      price: 0,
      priceId: null,
      features: [
        '1 user',
        '1 business',
        'Limited OCR (10/month)',
        'Basic reports',
        'Email support'
      ],
      limits: {
        users: 1,
        businesses: 1,
        ocrUploads: 10,
        reports: 'basic'
      }
    },
    {
      id: 'pro',
      name: 'Pro Tier',
      price: 19,
      priceId: 'price_pro_monthly',
      features: [
        'Unlimited users',
        'Advanced OCR',
        'AI Cost Suggestions',
        'Full reports',
        'Priority support'
      ],
      limits: {
        users: 'unlimited',
        businesses: 'unlimited',
        ocrUploads: 'unlimited',
        reports: 'full'
      }
    },
    {
      id: 'enterprise',
      name: 'Enterprise Tier',
      price: 99,
      priceId: 'price_enterprise_monthly',
      features: [
        'Custom integrations',
        'Audit Trail',
        'Priority Support',
        'Dedicated account manager',
        'Custom training'
      ],
      limits: {
        users: 'unlimited',
        businesses: 'unlimited',
        ocrUploads: 'unlimited',
        reports: 'enterprise'
      }
    }
  ]

  const fetchSubscription = async () => {
    if (!user) return

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', user.id)
        .single()

      if (!error && data) {
        setSubscription(data)
      } else {
        // Default to free plan
        const freeSubscription = {
          id: 'free_sub',
          user_id: user.id,
          plan: 'free',
          status: 'active',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          stripe_subscription_id: null
        }
        setSubscription(freeSubscription)
      }
    } catch (err) {
      console.warn('Failed to fetch subscription:', err)
      // Default to free plan
      const freeSubscription = {
        id: 'free_sub',
        user_id: user.id,
        plan: 'free',
        status: 'active',
        current_period_start: new Date().toISOString(),
        current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        stripe_subscription_id: null
      }
      setSubscription(freeSubscription)
    } finally {
      setLoading(false)
    }
  }

  const createCheckoutSession = async (planId) => {
    const plan = plans.find(p => p.id === planId)
    if (!plan || !plan.priceId) return { error: 'Invalid plan' }

    setLoading(true)
    try {
      // In a real implementation, this would call your backend API
      // which would create a Stripe checkout session
      const response = await fetch('/api/create-checkout-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          priceId: plan.priceId,
          userId: user.id,
          userEmail: user.email
        })
      })

      if (!response.ok) {
        throw new Error('Failed to create checkout session')
      }

      const { sessionId } = await response.json()
      
      // Redirect to Stripe Checkout
      const stripe = window.Stripe(STRIPE_PUBLISHABLE_KEY)
      const { error } = await stripe.redirectToCheckout({ sessionId })
      
      if (error) {
        throw error
      }

      return { success: true }
    } catch (error) {
      console.warn('Stripe checkout failed, using mock upgrade:', error)
      
      // Mock upgrade for demo purposes
      const upgradedSubscription = {
        ...subscription,
        plan: planId,
        status: 'active',
        stripe_subscription_id: `sub_mock_${Date.now()}`
      }
      
      setSubscription(upgradedSubscription)
      
      // Show success message
      alert(`Successfully upgraded to ${plan.name}! (Demo mode)`)
      
      return { success: true }
    } finally {
      setLoading(false)
    }
  }

  const cancelSubscription = async () => {
    if (!subscription?.stripe_subscription_id) return { error: 'No active subscription' }

    setLoading(true)
    try {
      // In a real implementation, this would call your backend API
      const response = await fetch('/api/cancel-subscription', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          subscriptionId: subscription.stripe_subscription_id
        })
      })

      if (!response.ok) {
        throw new Error('Failed to cancel subscription')
      }

      // Update local state
      const canceledSubscription = {
        ...subscription,
        status: 'canceled'
      }
      setSubscription(canceledSubscription)

      return { success: true }
    } catch (error) {
      console.warn('Subscription cancellation failed:', error)
      return { error: error.message }
    } finally {
      setLoading(false)
    }
  }

  const getCurrentPlan = () => {
    if (!subscription) return plans[0] // Default to free
    return plans.find(p => p.id === subscription.plan) || plans[0]
  }

  const canAccessFeature = (feature) => {
    const currentPlan = getCurrentPlan()
    
    switch (feature) {
      case 'unlimited_ocr':
        return currentPlan.id !== 'free'
      case 'ai_suggestions':
        return currentPlan.id !== 'free'
      case 'advanced_reports':
        return currentPlan.id !== 'free'
      case 'priority_support':
        return currentPlan.id !== 'free'
      case 'custom_integrations':
        return currentPlan.id === 'enterprise'
      case 'audit_trail':
        return currentPlan.id === 'enterprise'
      default:
        return true
    }
  }

  useEffect(() => {
    if (user) {
      fetchSubscription()
    }
  }, [user])

  return {
    subscription,
    loading,
    plans,
    createCheckoutSession,
    cancelSubscription,
    getCurrentPlan,
    canAccessFeature,
    fetchSubscription
  }
}

