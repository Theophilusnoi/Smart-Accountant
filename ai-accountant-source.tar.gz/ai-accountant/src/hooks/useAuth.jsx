import { useState, useEffect, createContext, useContext } from 'react'
import { supabase } from '../lib/supabase.js'

const AuthContext = createContext({})

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    const getInitialSession = async () => {
      const { data: { session } } = await supabase.auth.getSession()
      setUser(session?.user ?? null)
      setLoading(false)
    }

    getInitialSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    return () => subscription?.unsubscribe()
  }, [])

  const signIn = async (email, password) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      })
      
      if (error) {
        // For demo purposes, fall back to mock authentication if Supabase is not configured
        console.warn('Supabase auth failed, using mock auth:', error.message)
        const mockUser = {
          id: '1',
          email,
          user_metadata: {
            name: email.split('@')[0],
            first_name: email.split('@')[0],
            last_name: 'User'
          },
          created_at: new Date().toISOString()
        }
        
        setUser(mockUser)
        localStorage.setItem('ai-accountant-user', JSON.stringify(mockUser))
        return { user: mockUser, error: null }
      }

      return { user: data.user, error: null }
    } catch (err) {
      return { user: null, error: err }
    }
  }

  const signUp = async (email, password, firstName, lastName) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            first_name: firstName,
            last_name: lastName,
            name: `${firstName} ${lastName}`
          }
        }
      })
      
      if (error) {
        // For demo purposes, fall back to mock authentication if Supabase is not configured
        console.warn('Supabase auth failed, using mock auth:', error.message)
        const mockUser = {
          id: '1',
          email,
          user_metadata: {
            name: `${firstName} ${lastName}`,
            first_name: firstName,
            last_name: lastName
          },
          created_at: new Date().toISOString()
        }
        
        setUser(mockUser)
        localStorage.setItem('ai-accountant-user', JSON.stringify(mockUser))
        return { user: mockUser, error: null }
      }

      return { user: data.user, error: null }
    } catch (err) {
      return { user: null, error: err }
    }
  }

  const signOut = async () => {
    try {
      await supabase.auth.signOut()
    } catch (err) {
      console.warn('Supabase signout failed, clearing local storage')
    }
    
    setUser(null)
    localStorage.removeItem('ai-accountant-user')
  }

  const value = {
    user,
    loading,
    signIn,
    signUp,
    signOut
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

